namespace MemberGest;

using MemberGest.Context;
using MemberGest.Models;
using MemberGest.Services;
using Microsoft.EntityFrameworkCore;
using Xunit;
using System.Threading.Tasks;
using System;
using System.Linq;

public class SeatServiceTest
{
    private DbContextOptions<ApplicationDbContext> optionBuilder;

    public SeatServiceTest()
    {
        optionBuilder = new DbContextOptionsBuilder<ApplicationDbContext>()
            .UseInMemoryDatabase(Guid.NewGuid().ToString()).Options;
    }

    [Fact]
    public async Task ObtenerAsientosAsync_FilterByLibraryId_Ok()
    {
        using var context = new ApplicationDbContext(optionBuilder);
        var handler = new HttpClientHandler
        {
            ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => true
        };
        var inMemorySettings = new Dictionary<string, string>
        {
            {"NotificationUtility", "something"}
        };


        HttpClient httpClient = new HttpClient(handler);
        IConfiguration config = new ConfigurationBuilder().AddInMemoryCollection(inMemorySettings).Build();

        var library1 = new Library { Id = 1, Name = "Central", Email = "test@library1.com", CIF = "A12345678", PhoneNumber = "123456789", Address = "...", Description = "...", Photo = new byte[] { 0x01, 0x02, 0x03 },PhotoMimeType="image/jpg",FloorNumbers=3,UserCreatedId=1 };
        var library2 = new Library { Id = 2, Name = "Norte", Email = "test@library2.com", CIF = "B12345678", PhoneNumber = "123456789", Address = "...", Description = "...", Photo = new byte[] { 0x01, 0x02, 0x03 }, PhotoMimeType = "image/jpg", FloorNumbers = 3, UserCreatedId = 1 };
        context.Library.AddRange(library1, library2);

        var seat1 = new Seat { Id = 1, Status = "Disponible", FloorNum = 1, Library = library1, LibraryId = 1, Remarks="" };
        var seat2 = new Seat { Id = 2, Status = "Disponible", FloorNum = 1, Library = library2, LibraryId = 2, Remarks="" };
        context.Seat.AddRange(seat1, seat2);

        await context.SaveChangesAsync();

        var service = new SeatService(context, config, httpClient);
        var searchParams = new SeatSearchParams
        {
            Library = "Central",
        };

        var result = await service.ObtenerAsientosAsync(searchParams);

        Assert.Single(result.Items);
        Assert.Equal(1, result.Items.First().LibraryId);

    }
}
