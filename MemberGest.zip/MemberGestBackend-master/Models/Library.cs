﻿using System.Security.Policy;

namespace MemberGest.Models
{
    public class Library
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string CIF { get; set; }
        public string PhoneNumber { get; set; }
        public string Address { get; set; }
        public string Description { get; set; }
        public byte[] Photo {  get; set; }
        public string PhotoMimeType { get; set; }
        public int FloorNumbers { get; set; }

        public int UserCreatedId { get; set; }
        public User UserCreated { get; set; }

    }
}
