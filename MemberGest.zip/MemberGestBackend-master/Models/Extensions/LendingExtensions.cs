﻿namespace MemberGest.Models.Extensions
{
    public static class LendingExtensions
    {
        public static LendingDetailsDTO ToDetailsDTO(this Lending lending)
        {
            return new LendingDetailsDTO
            {
                Status = lending.Status,
                UserReservedId = lending.UserReservedId,
                Id = lending.Id,
                LendingInitDate = lending.LendingInitDate,
                LendingFinishDate = lending.LendingFinishDate,
                CopyBookId = lending.CopyBookId,
                BookId = lending.CopyBookLending.BookId,
                Book = lending.CopyBookLending.Book.Title,
                Library = lending.CopyBookLending.Library.Name,
            };
        }

        public static Lending ToLending(this LendingCreateDTO reserve)
        {
            return new Lending
            {
                LendingInitDate = reserve.LendingInitDate,
                CopyBookId = reserve.CopyBookId,
            };
        }
    }
}
