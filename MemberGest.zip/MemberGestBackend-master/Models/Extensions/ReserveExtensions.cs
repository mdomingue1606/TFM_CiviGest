﻿namespace MemberGest.Models.Extensions
{
    public static class ReserveExtensions
    {
        public static ReserveDetailsDTO ToDetailsDTO(this Reserve reserve)
        {
            return new ReserveDetailsDTO
            {
                Status = reserve.Status,
                UserReservedId = reserve.UserReservedId,
                Id = reserve.Id,
                ReserveDate = reserve.ReserveDate,
                SeatReservedId = reserve.SeatReservedId,
                FloorNum = reserve.SeatReserved.FloorNum,
                RoomNum = reserve.SeatReserved.RoomNum,
                SeatNum = reserve.SeatReserved.SeatNum,
                Library = reserve.SeatReserved.Library.Name,
                LibraryId = reserve.SeatReserved.LibraryId
            };
        }

        public static Reserve ToReserve(this ReserveCreateDTO reserve)
        {
            return new Reserve
            {
                ReserveDate = reserve.ReserveDate,
                SeatReservedId = reserve.SeatReservedId,
            };
        }
    }
}
