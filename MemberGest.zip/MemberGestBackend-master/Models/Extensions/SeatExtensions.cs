﻿namespace MemberGest.Models.Extensions
{
    public static class SeatExtensions
    {
        public static SeatDetailsDTO ToDetailsDTO(this Seat seat)
        {
            return new SeatDetailsDTO
            {
                LibraryId = seat.LibraryId,
                FloorNum = seat.FloorNum,
                HasSocket = seat.HasSocket,
                HasWindow = seat.HasWindow,
                IsWCNear = seat.IsWCNear,
                Remarks = seat.Remarks,
                RoomNum = seat.RoomNum,
                SeatNum = seat.SeatNum,
                Status = seat.Status,
                UserCreatedId = seat.UserCreatedId,
                Id = seat.Id,
            };
        }

        public static Seat ToSeat(this SeatCreateDTO seat)
        {
            return new Seat
            {
                FloorNum = seat.FloorNum,
                HasSocket = seat.HasSocket,
                IsWCNear = seat.IsWCNear,
                LibraryId = seat.LibraryId,
                RoomNum = seat.RoomNum,
                SeatNum = seat.SeatNum,
                HasWindow = seat.HasWindow,
                Status = seat.Status
            };
        }
    }
}
