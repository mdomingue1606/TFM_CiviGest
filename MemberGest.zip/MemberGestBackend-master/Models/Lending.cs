﻿using Microsoft.CodeAnalysis.FlowAnalysis.DataFlow.CopyAnalysis;

namespace MemberGest.Models
{
    public class Lending
    {
        public int Id { get; set; }
        public DateOnly LendingInitDate { get; set; }
        public DateOnly? LendingFinishDate { get; set; }
        public string? Status { get; set; }

        public int UserReservedId { get; set; }
        public User UserReserved { get; set; }

        public int CopyBookId { get; set; }
        public CopyBook CopyBookLending { get; set; }
    }


    public class LendingCreateDTO
    {
        public DateOnly LendingInitDate { get; set; }
        public int CopyBookId { get; set; }
    }

    public class LendingDetailsDTO //Revisar
    {
        public int Id { get; set; }
        public DateOnly LendingInitDate { get; set; }
        public DateOnly? LendingFinishDate { get; set; }
        public string? Status { get; set; }
        public int UserReservedId { get; set; }
        public int? CopyBookId { get; set; }
        public int BookId { get; set; }
        public string Book { get; set; }
        public string Library { get; set; }
    }

    public class LendingSearchParams //Revisar
    {
        public int PageNum { get; set; } = 0;
        public int PageSize { get; set; } = 10;
        public int? UserId { get; set; }
        public string? Username { get; set; }
        public string? Status { get; set; }
        public string? Book { get; set; }
        public int? CopyBookId { get; set; }
        public string? OrderBy { get; set; }
        public string? OrderField { get; set; }
    }

}
