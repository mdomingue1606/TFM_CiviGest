﻿namespace MemberGest.Models
{
    public class CopyBook
    {
        public int Id { get; set; }
        public string Status { get; set; }
        public string Ubication { get; set; }
        public string EditionNum { get; set; }
        public DateOnly PurchaseDate { get; set; }
        public string Remarks { get; set; }

        public int UserCreatedId { get; set; }
        public User UserCreated { get; set; }

        public int BookId { get; set; }
        public Book Book { get; set; }

        public int LibraryId { get; set; }
        public Library Library { get; set; }
    }
}
