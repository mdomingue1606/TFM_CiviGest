﻿namespace MemberGest.Models
{
    public class CreateEmail
    {
        public string RecipientEmail { get; set; }
        public string Content { get; set; }
        public string Subject { get; set; }
    }
}
