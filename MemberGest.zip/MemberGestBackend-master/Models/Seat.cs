﻿using System.Security.Policy;

namespace MemberGest.Models
{
    public class Seat
    {
        public int Id { get; set; }
        public int SeatNum { get; set; }
        public int FloorNum { get; set; }
        public int RoomNum { get; set; }
        public string Remarks { get; set; }
        public bool HasWindow { get; set; }
        public bool HasSocket { get; set; }
        public bool IsWCNear { get; set; }
        public string Status { get; set; }


        public int UserCreatedId { get; set; }
        public User UserCreated { get; set; }

        public int LibraryId { get; set; }
        public Library Library { get; set; }

    }

    public class SeatCreateDTO
    {
        public int SeatNum { get; set; }
        public int FloorNum { get; set; }
        public int RoomNum { get; set; }
        public bool HasWindow { get; set; }
        public bool HasSocket { get; set; }
        public bool IsWCNear { get; set; }
        public string Status { get; set; }
        public int LibraryId { get; set; }
    }

    public class SeatDetailsDTO
    {
        public int SeatNum { get; set; }
        public int FloorNum { get; set; }
        public int RoomNum { get; set; }
        public bool HasWindow { get; set; }
        public bool HasSocket { get; set; }
        public bool IsWCNear { get; set; }
        public string Status { get; set; }
        public int LibraryId { get; set; }
        public int Id { get; set; }
        public int UserCreatedId { get; set; }
        public string Remarks { get; set; }

    }

    public class SeatSearchParams // REVISAR
    {
        public int PageNum { get; set; } = 0;
        public int PageSize { get; set; } = 10;
        public int? LibraryId { get; set; }
        public string? Library { get; set; }
        public string? Status { get; set; }
        public int? FloorNum { get; set; }
        public int? RoomNum { get; set; }
        public bool? HasWindow { get; set; }
        public bool? HasSocket { get; set; }
        public bool? IsWCNear { get; set; }
        public string? OrderBy { get; set; }
        public string? OrderField { get; set; }
    }
}
