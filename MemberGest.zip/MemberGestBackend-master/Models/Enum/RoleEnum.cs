﻿namespace MemberGest.Models.Enum
{
    public enum RoleEnum
    {
        Admin,
        Gestor,
        Cliente
    }
}
