﻿namespace MemberGest.Models.Enum
{
    public enum SeatStatusEnum
    {
        Disponible,
        Ocupado,
        Dañado
    }
}
