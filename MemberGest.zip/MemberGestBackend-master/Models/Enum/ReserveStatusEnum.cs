﻿namespace MemberGest.Models.Enum
{
    public enum ReserveStatusEnum
    {
        Asiste,
        Ausencia
    }
}
