﻿using System.Security.Policy;

namespace MemberGest.Models
{
    public class Reserve
    {
        public int Id { get; set; }
        public DateOnly ReserveDate { get; set; }
        public string? Status { get; set; }

        public int UserReservedId { get; set; }
        public User UserReserved { get; set; }

        public int SeatReservedId { get; set; }
        public Seat SeatReserved { get; set; }


    }

    public class ReserveCreateDTO
    {
        public DateOnly ReserveDate { get; set; }
        public int SeatReservedId { get; set; }
        public string LibraryName { get; set; }
        public string FloorNum { get; set; }
        public string RoomNum { get; set; }
        public string SeatNum { get; set; }
    }

    public class ReserveDetailsDTO //Revisar
    {
        public int Id { get; set; }
        public DateOnly? ReserveDate { get; set; }
        public string? Status { get; set; }
        public int UserReservedId { get; set; }
        public int? SeatReservedId { get; set; }
        public int LibraryId { get; set; }
        public string Library { get; set; }
        public int SeatNum { get; set; }
        public int FloorNum { get; set; }
        public int RoomNum { get; set; }
    }

    public class ReserveSearchParams //Revisar
    {
        public int PageNum { get; set; } = 0;
        public int PageSize { get; set; } = 10;
        public int? UserId { get; set; }
        public string? Username { get; set; }
        public string? Status { get; set; }
        public string? Library { get; set; }
        public int? LibraryId { get; set; }
        public int? Floor { get; set; }
        public DateOnly? ReserveDate { get; set; }
        public string? OrderBy { get; set; }
        public string? OrderField { get; set; }
    }
}
