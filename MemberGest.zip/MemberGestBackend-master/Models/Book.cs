﻿namespace MemberGest.Models
{
    public class Book
    {
        public int Id { get; set; }
        public string ISBN { get; set; }
        public string Title { get; set; }
        public string Summary { get; set; }
        public string PagNum { get; set; }
        public DateOnly PublicationDate { get; set; }
        public string Publisher { get; set; }
        public byte[] Photo { get; set; }
        public string PhotoMimeType { get; set; }

        public int UserCreatedId { get; set; }
        public User UserCreated { get; set; }

        public ICollection<AuthorBook> AuthorBooks { get; set; } = new List<AuthorBook>();
    }

    public class AuthorBook
    {
        public int AuthorId { get; set; }
        public Author Author { get; set; }
        public int BookId { get; set; }
        public Book Book { get; set; }
    }

    public class Author
    {
        public int Id { get; set; }
        public string NameSurname { get; set; }
        public ICollection<AuthorBook> AuthorBooks { get; set; } = new List<AuthorBook>();
        public ICollection<AuthorArchive> AuthorArchives { get; set; } = new List<AuthorArchive>();
    }

    public class AuthorArchive
    {
        public int AuthorId { get; set; }
        public Author Author { get; set; }
        public int ArchiveId { get; set; }
        public Archive Archive { get; set; }
    }

    public class Archive
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Summary { get; set; }
        public DateOnly PublicationDate { get; set; }
        public string FileMimeType { get; set; }
        public byte[] File { get; set; }

        public int UserCreatedId { get; set; }
        public User UserCreated { get; set; }

        public ICollection<AuthorArchive> AuthorArchives { get; set; } = new List<AuthorArchive>();

    }



}
