﻿using System.Text.Json;
using MemberGest.Models;
using Microsoft.EntityFrameworkCore;

namespace MemberGest.Context
{
    public class ApplicationDbContext : DbContext
    {
        public DbSet<Configuration> Configuration { get; set; }
        public DbSet<Library> Library { get; set; }
        public DbSet<Seat> Seat { get; set; }
        public DbSet<Reserve> Reserve { get; set; }
        public DbSet<Lending>  Lending { get; set; }
        public DbSet<Book> Book { get; set; }
        public DbSet<CopyBook> CopyBook { get; set; }

        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
      : base(options)
        {
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Configuration>()
                .Property(c => c.Audience)
                .HasConversion(
                    v => SerializeList(v),
                    v => DeserializeList(v));

            //Relation between User and USerRole
            modelBuilder.Entity<User>()
                .HasOne(u => u.Role)
                .WithMany()
                .HasForeignKey(u => u.UserRoleId)
                .OnDelete(DeleteBehavior.Restrict);

            //Relation between Library and User
            modelBuilder.Entity<Library>()
                .HasOne(p => p.UserCreated)
                .WithMany()
                .HasForeignKey(p => p.UserCreatedId)
                .OnDelete(DeleteBehavior.Restrict);

            //Relation between Seat and User
            modelBuilder.Entity<Seat>()
                .HasOne(p => p.UserCreated)
                .WithMany()
                .HasForeignKey(p => p.UserCreatedId)
                .OnDelete(DeleteBehavior.Restrict);

            //Relation between Seat and Library
            modelBuilder.Entity<Seat>()
                .HasOne(p => p.Library)
                .WithMany()
                .HasForeignKey(p => p.LibraryId)
                .OnDelete(DeleteBehavior.Restrict);

            //Relation between Reserve and Seat
            modelBuilder.Entity<Reserve>()
               .HasOne(p => p.SeatReserved)
               .WithMany()
               .HasForeignKey(p => p.SeatReservedId)
               .OnDelete(DeleteBehavior.Restrict);

            //Relation between Reserve and User
            modelBuilder.Entity<Reserve>()
               .HasOne(p => p.UserReserved)
               .WithMany()
               .HasForeignKey(p => p.UserReservedId)
               .OnDelete(DeleteBehavior.Restrict);

            //Relation between User and Leading
            modelBuilder.Entity<Lending>()
               .HasOne(p => p.UserReserved)
               .WithMany()
               .HasForeignKey(p => p.UserReservedId)
               .OnDelete(DeleteBehavior.Restrict);

            //Relation between Lending and CopyBook
            modelBuilder.Entity<Lending>()
               .HasOne(p => p.CopyBookLending)
               .WithMany()
               .HasForeignKey(p => p.CopyBookId)
               .OnDelete(DeleteBehavior.Restrict);

            //Relation between CopyBook and rest
            modelBuilder.Entity<CopyBook>()
                .HasOne(p => p.UserCreated)
                .WithMany()
                .HasForeignKey(p => p.UserCreatedId)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<CopyBook>()
                .HasOne(p => p.Book)
                .WithMany()
                .HasForeignKey(p => p.BookId)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<CopyBook>()
                .HasOne(p => p.Library)
                .WithMany()
                .HasForeignKey(p => p.LibraryId)
                .OnDelete(DeleteBehavior.Restrict);

            //Relation between authors and books
            modelBuilder.Entity<AuthorBook>()
                .HasKey(ab => new { ab.BookId, ab.AuthorId });

            modelBuilder.Entity<AuthorBook>()
                .HasOne(ab => ab.Author)
                .WithMany(a => a.AuthorBooks)
                .HasForeignKey(ab => ab.AuthorId);

            modelBuilder.Entity<AuthorBook>()
                .HasOne(ab => ab.Book)
                .WithMany(a => a.AuthorBooks)
                .HasForeignKey(ab => ab.BookId);

            //Relation between archives and authors
            modelBuilder.Entity<AuthorArchive>()
                .HasKey(ab => new { ab.ArchiveId, ab.AuthorId });

            modelBuilder.Entity<AuthorArchive>()
                .HasOne(ab => ab.Author)
                .WithMany(a => a.AuthorArchives)
                .HasForeignKey(ab => ab.AuthorId);

            modelBuilder.Entity<AuthorArchive>()
                .HasOne(ab => ab.Archive)
                .WithMany(a => a.AuthorArchives)
                .HasForeignKey(ab => ab.ArchiveId);

            //Relation between Archive and User
            modelBuilder.Entity<Archive>()
                .HasOne(p => p.UserCreated)
                .WithMany()
                .HasForeignKey(p => p.UserCreatedId)
                .OnDelete(DeleteBehavior.Restrict);
        }

        private string SerializeList(List<string> list)
        {
            return JsonSerializer.Serialize(list);
        }

        // Deserialize Method
        private List<string> DeserializeList(string json)
        {
            Console.WriteLine(json);
            return JsonSerializer.Deserialize<List<string>>(json);
        }
    }
}
