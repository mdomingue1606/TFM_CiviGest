﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MemberGest.Context;
using MemberGest.Models;
using MemberGest.Services;
using Microsoft.AspNetCore.Authorization;

namespace MemberGest.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LendingsController : ControllerBase
    {
        private readonly ICurrentInfoAuthService currentInfoAuthService;
        private readonly ILendingService lendingService;

        public LendingsController(ILendingService lendingService, ICurrentInfoAuthService currentInfoAuthService)
        {
            this.currentInfoAuthService = currentInfoAuthService;
            this.lendingService = lendingService;
        }

        // GET: api/Lendings
        [HttpGet]
        [Authorize]
        public async Task<ActionResult<PageResult<LendingDetailsDTO>>> GetLending(int npag = 0, int nelem = 10, string? estado = null, string? usuario = null,
                                                                                    int? usuarioId = null, int? ejemplarId = null,
                                                                                    string? libro = null, string? orden = null, string? campoOrden = null)
        {
            LendingSearchParams pSearchParams = new LendingSearchParams
            {
                PageSize = nelem,
                PageNum = npag,
                OrderBy = orden,
                OrderField = campoOrden,
                Status = estado,
                Book = libro,
                CopyBookId = ejemplarId,
                UserId = usuarioId,
                Username = usuario
            };
            return await lendingService.ObtenerPrestamosAsync(pSearchParams);
        }

        // GET: api/Lendings/5
        [HttpGet("{id}")]
        [Authorize]
        public async Task<ActionResult<LendingDetailsDTO>> GetLending(int id)
        {
            var lending = await lendingService.ObtenerPrestamoDetallesIdAsync(id);

            if (lending == null)
            {
                return NotFound();
            }

            return lending;
        }

        // PUT: api/Lendings/5
        [HttpPut("{id}")]
        [Authorize(Roles = "Admin,Gestor")]
        public async Task<IActionResult> PutLending(int id, [FromBody] LendingDetailsDTO lending)
        {
            try
            {
                CurrentUserInfoAuth infoUser = currentInfoAuthService.ObtenerInfoAuth(Request);
                var res = await lendingService.ActualizarPrestamoAsync(id, lending, infoUser);
                if (!res)
                {
                    return NotFound();
                }
                return NoContent();
            }
            catch (UnauthorizedAccessException ex)
            {
                return Unauthorized(ex.Message);
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!lendingService.ExistePrestamo(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }
        }

        // POST: api/Lendings
        [HttpPost]
        [Authorize]
        public async Task<ActionResult<Lending>> PostLending(LendingCreateDTO lending)
        {
            try
            {
                CurrentUserInfoAuth infoUser = currentInfoAuthService.ObtenerInfoAuth(Request);
                if (infoUser.Id == null)
                {
                    return BadRequest("El token no está bien formado");
                }
                await lendingService.CrearPrestamoAsync(lending, infoUser.Id.Value);

                return Created("", new { message = "Prestamo creado", lending });
            }
            catch (ArgumentException ex)
            {
                return BadRequest(new { error = ex.Message });
            }
        }

        // DELETE: api/Lendings/5
        [HttpDelete("{id}")]
        [Authorize]
        public async Task<IActionResult> DeleteLending(int id)
        {
            try
            {
                CurrentUserInfoAuth infoUser = currentInfoAuthService.ObtenerInfoAuth(Request);
                var res = await lendingService.EliminarPrestamoAsync(id, infoUser);
                if (!res)
                {
                    return NotFound();
                }

                return NoContent();
            }
            catch (UnauthorizedAccessException ex)
            {
                return Unauthorized(ex.Message);
            }
        }

    }
}
