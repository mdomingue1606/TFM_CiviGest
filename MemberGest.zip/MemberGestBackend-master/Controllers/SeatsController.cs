﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MemberGest.Context;
using MemberGest.Models;
using MemberGest.Services;
using Microsoft.AspNetCore.Authorization;

namespace MemberGest.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SeatsController : ControllerBase
    {
        private readonly ISeatService seatService;
        private readonly ICurrentInfoAuthService currentInfoAuthService;
        public SeatsController(ISeatService seatService, ICurrentInfoAuthService currentInfoAuthService)
        {
            this.currentInfoAuthService = currentInfoAuthService;
            this.seatService = seatService;
        }

        // GET: api/Seats
        [HttpGet]
        public async Task<ActionResult<PageResult<SeatDetailsDTO>>> GetSeat(int npag = 0, int nelem = 10, int? biblioId = null, string? estado = null, bool? hayVentana = null,
                                                                                    int? plantaNum = null, int? salaNum = null, bool? wcCerca = null, bool? hayEnchufe = null,
                                                                                    string? biblio = null, string? orden = null, string? campoOrden = null)
        {
            SeatSearchParams pSearchParams = new SeatSearchParams
            {
                PageSize = nelem,
                PageNum = npag,
                OrderBy = orden,
                OrderField = campoOrden,
                Status = estado,
                FloorNum = plantaNum,
                RoomNum = salaNum,
                HasWindow = hayVentana,
                HasSocket = hayEnchufe,
                IsWCNear = wcCerca,
                LibraryId = biblioId,
                Library = biblio
            };
            return await seatService.ObtenerAsientosAsync(pSearchParams);
        }

        // GET: api/Seats/5
        [HttpGet("{id}")]
        public async Task<ActionResult<SeatDetailsDTO>> GetSeat(int id)
        {
            var seat = await seatService.ObtenerAsientoDetallesIdAsync(id);

            if (seat == null)
            {
                return NotFound();
            }

            return seat;
        }

        // PUT: api/Seats/5
        [HttpPut("{id}")]
        [Authorize(Roles = "Admin,Gestor")]
        public async Task<IActionResult> PutSeat(int id, [FromBody] SeatDetailsDTO seat)
        {
            try
            {
                CurrentUserInfoAuth infoUser = currentInfoAuthService.ObtenerInfoAuth(Request);
                var res = await seatService.ActualizarAsientoAsync(id, seat, infoUser);
                if (!res)
                {
                    return NotFound();
                }
                return NoContent();
            }
            catch (UnauthorizedAccessException ex)
            {
                return Unauthorized(ex.Message);
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!seatService.ExisteAsiento(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }
        }

        // POST: api/Seats
        [HttpPost]
        [Authorize(Roles = "Admin,Gestor")]
        public async Task<ActionResult<Seat>> PostSeat(SeatCreateDTO seat)
        {
            try
            {
                CurrentUserInfoAuth infoUser = currentInfoAuthService.ObtenerInfoAuth(Request);
                if (infoUser.Id == null)
                {
                    return BadRequest("El token no está bien formado");
                }
                await seatService.CrearAsientoAsync(seat, infoUser.Id.Value);

                return Created("", new { message = "Asiento creado", seat });
            }
            catch (ArgumentException ex)
            {
                return BadRequest(new { error = ex.Message });
            }
        }

        // DELETE: api/Seats/5
        [HttpDelete("{id}")]
        [Authorize(Roles = "Admin,Gestor")]
        public async Task<IActionResult> DeleteSeat(int id)
        {
            try
            {
                CurrentUserInfoAuth infoUser = currentInfoAuthService.ObtenerInfoAuth(Request);
                var res = await seatService.EliminarAsientoAsync(id, infoUser);
                if (!res)
                {
                    return NotFound();
                }

                return NoContent();
            }
            catch (UnauthorizedAccessException ex)
            {
                return Unauthorized(ex.Message);
            }
        }

        //RESERVES

        // GET: api/Seats/Reserves
        [HttpGet("Reserves")]
        [Authorize]
        public async Task<ActionResult<PageResult<ReserveDetailsDTO>>> GetReserve(int npag = 0, int nelem = 10, int? biblioId = null, string? estado = null, int? planta = null,
                                                                                    int? userId = null, string? usuario = null, string? biblio = null, 
                                                                                    string? orden = null, string? campoOrden = null, string? fecha = null)
        {
         DateOnly? date = null;
            if(fecha != null)
            {
                date = DateOnly.Parse(fecha);
            }

            ReserveSearchParams pSearchParams = new ReserveSearchParams
            {
                PageSize = nelem,
                PageNum = npag,
                OrderBy = orden,
                OrderField = campoOrden,
                Status = estado,
                UserId = userId,
                Username = usuario,
                LibraryId = biblioId,
                Library = biblio,
                Floor = planta,
                ReserveDate = date
            };
            return await seatService.ObtenerReservasAsync(pSearchParams);
        }

        // GET: api/Seat/Reserves/5
        [HttpGet("Reserves/{id}")]
        [Authorize]
        public async Task<ActionResult<ReserveDetailsDTO>> GetReserve(int id)
        {
            var reserve = await seatService.ObtenerReservaDetallesIdAsync(id);

            if (reserve == null)
            {
                return NotFound();
            }

            return reserve;
        }

        // PUT: api/Seats/Reserves/5
        [HttpPut("Reserves/{id}")]
        [Authorize]
        public async Task<IActionResult> PutReserve(int id, [FromBody] ReserveDetailsDTO reserve)
        {
            try
            {
                CurrentUserInfoAuth infoUser = currentInfoAuthService.ObtenerInfoAuth(Request);
                var res = await seatService.ActualizarReservaAsync(id, reserve, infoUser);
                if (!res)
                {
                    return NotFound();
                }
                return NoContent();
            }
            catch (UnauthorizedAccessException ex)
            {
                return Unauthorized(ex.Message);
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!seatService.ExisteReserva(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }
        }

        // POST: api/Seats/Reserves
        [HttpPost("Reserves")]
        [Authorize]
        public async Task<ActionResult<Reserve>> PostReserve(ReserveCreateDTO reserve)
        {
            try
            {
                CurrentUserInfoAuth infoUser = currentInfoAuthService.ObtenerInfoAuth(Request);
                if (infoUser.Id == null)
                {
                    return BadRequest("El token no está bien formado");
                }
                await seatService.CrearReservaAsync(reserve, infoUser.Id.Value, infoUser.Email);

                return Created("", new { message = "Reserva creada", reserve });
            }
            catch (ArgumentException ex)
            {
                return BadRequest(new { error = ex.Message });
            }
        }

        // DELETE: api/Seats/Reserves/5
        [HttpDelete("Reserves/{id}")]
        [Authorize]
        public async Task<IActionResult> DeleteReserve(int id)
        {
            try
            {
                CurrentUserInfoAuth infoUser = currentInfoAuthService.ObtenerInfoAuth(Request);
                var res = await seatService.EliminarReservaAsync(id, infoUser);
                if (!res)
                {
                    return NotFound();
                }

                return NoContent();
            }
            catch (UnauthorizedAccessException ex)
            {
                return Unauthorized(ex.Message);
            }
        }

    }
}
