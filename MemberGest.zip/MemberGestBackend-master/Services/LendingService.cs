﻿using MemberGest.Models.Enum;
using MemberGest.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using MemberGest.Context;
using MemberGest.Models.Extensions;

namespace MemberGest.Services
{
    public class LendingService : ILendingService
    {
        private readonly ApplicationDbContext context;
        public LendingService(ApplicationDbContext context) {
            this.context = context;
        }

        public async Task<Lending?> ObtenerPrestamoIdAsync(int id)
        {
            return await context.Lending.Include(r => r.CopyBookLending).ThenInclude(s => s.Book)
                                        .Include(r => r.CopyBookLending).ThenInclude(s => s.Library)
                                        .FirstOrDefaultAsync(r => r.Id == id);
        }

        public async Task<LendingDetailsDTO?> ObtenerPrestamoDetallesIdAsync(int id)
        {
            Lending lending = await ObtenerPrestamoIdAsync(id);
            LendingDetailsDTO? res = null;
            if (lending != null)
            {
                res = lending.ToDetailsDTO();
            }
            return res;
        }

        public async Task CrearPrestamoAsync(LendingCreateDTO data, int userReservedId)
        {
            //Check if it ithis copybook is lending
            bool lendingExists = await ExistePrestamoEjemplar(data.CopyBookId);
            if (lendingExists)
            {
                throw new ArgumentException("El ejemplar ya está prestado.");
            }
            //Check that this user has not already one lending
            bool hasUserReserve = await ExistePrestamoUsuario(userReservedId);
            if (hasUserReserve)
            {
                throw new ArgumentException("No puedes realizar un prestamo, ya tienes uno realizado.");
            }

            var lending = data.ToLending();
            //Add the user who is reserving the seat
            lending.UserReservedId = userReservedId;
            lending.Status = "Solicitado";


            context.Lending.Add(lending);
            await context.SaveChangesAsync();
        }

        public async Task<bool> EliminarPrestamoAsync(int id, CurrentUserInfoAuth infoUser)
        {

            var lending = await ObtenerPrestamoIdAsync(id);
            if (lending != null)
            {
                //If it is a client he only can remove his own lending.
                if (infoUser.Role == RoleEnum.Cliente.ToString() && lending.UserReservedId != infoUser.Id)
                {
                    throw new UnauthorizedAccessException("No tienes permisos para ello");
                }

                context.Remove(lending);
                await context.SaveChangesAsync();
                return true;

            }
            return false;

        }
        public async Task<PageResult<LendingDetailsDTO>> ObtenerPrestamosAsync(LendingSearchParams pSearchParams)
        {
            var query = context.Lending
                .Include(r => r.CopyBookLending).ThenInclude(s => s.Book)
                .Include(r => r.CopyBookLending).ThenInclude(s => s.Library).Include(r => r.UserReserved)
                .AsQueryable();

            //Filter for the status
            if (!string.IsNullOrEmpty(pSearchParams.Status))
            {
                query = query.Where(u => u.Status.Contains(pSearchParams.Status));
            }

            //Filter for the user
            if (pSearchParams.UserId.HasValue)
            {
                query = query.Where(p => p.UserReservedId.Equals(pSearchParams.UserId));
            }

            //Filter for the username
            if (!string.IsNullOrEmpty(pSearchParams.Username))
            {
                query = query.Where(p => p.UserReserved.Name.Equals(pSearchParams.Username));
            }

            //Filter for the book
            if (!string.IsNullOrEmpty(pSearchParams.Book))
            {
                query = query.Where(p => p.CopyBookLending.Book.Title.Contains(pSearchParams.Book));
            }

            //Filter for the copyBook
            if (pSearchParams.CopyBookId.HasValue)
            {
                query = query.Where(p => p.CopyBookId.Equals(pSearchParams.CopyBookId));
            }

            // Order by library 
            if (pSearchParams.OrderField?.ToLower() == "fechaIni")
            {
                query = pSearchParams.OrderBy?.ToLower() == "desc"
                    ? query.OrderByDescending(p => p.LendingInitDate)
                    : query.OrderBy(p => p.LendingInitDate);
            }

            // Order by floor
            if (pSearchParams.OrderField?.ToLower() == "fechaFin")
            {
                query = pSearchParams.OrderBy?.ToLower() == "desc"
                    ? query.OrderByDescending(p => p.LendingFinishDate)
                    : query.OrderBy(p => p.LendingFinishDate);
            }

            //Get totalElements
            var totalItems = await query.CountAsync();

            //Get totalPages
            var totalPages = (int)Math.Ceiling(totalItems / (double)pSearchParams.PageSize);

            // Pages.
            query = query.Skip(pSearchParams.PageNum * pSearchParams.PageSize)
                         .Take(pSearchParams.PageSize);

            var list = await query.ToListAsync();

            // Convert to DTO
            List<LendingDetailsDTO> lendings = list.Select(p => p.ToDetailsDTO()).ToList();
            return new PageResult<LendingDetailsDTO>
            {
                Items = lendings,
                TotalItems = totalItems,
                TotalPages = totalPages,
                CurrentPage = pSearchParams.PageNum,
                PageSize = pSearchParams.PageSize
            };
        }

        public async Task<bool> ActualizarPrestamoAsync(int id, LendingDetailsDTO data, CurrentUserInfoAuth infoUser)
        {
            Lending lending = await ObtenerPrestamoIdAsync(id);
            if (lending != null)
            {
                //If it is a client he only can update his own lendings.
                if (infoUser.Role == RoleEnum.Cliente.ToString() && lending.UserReservedId != infoUser.Id)
                {
                    throw new UnauthorizedAccessException("No tienes permisos para ello");
                }
                //It only can be updated if it is not finished
                if (lending.LendingFinishDate != null)
                {
                    throw new UnauthorizedAccessException("No puedes modificar una prestamo que ya ha pasado");
                }

                lending.LendingFinishDate = data.LendingFinishDate;
                lending.Status = data.Status;

                context.Entry(lending).State = EntityState.Modified;
                await context.SaveChangesAsync();
                return true;
            }
            return false;

        }

        public bool ExistePrestamo(int id)
        {
            return context.Lending.Any(e => e.Id == id);
        }

        public async Task<bool> ExistePrestamoEjemplar(int copybookId)
        {
            return await context.Lending.AnyAsync(s => s.CopyBookId == copybookId && s.LendingFinishDate == null);
        }

        public async Task<bool> ExistePrestamoUsuario(int userID)
        {
            return await context.Lending.AnyAsync(s => s.LendingFinishDate == null && userID == s.UserReservedId);
        }
    }
}
