﻿using MemberGest.Models;

namespace MemberGest.Services
{
    public interface ICurrentInfoAuthService
    {
        CurrentUserInfoAuth ObtenerInfoAuth(HttpRequest request);
    }
}
