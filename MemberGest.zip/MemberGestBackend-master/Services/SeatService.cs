﻿using System.Net.Http;
using MemberGest.Context;
using MemberGest.Models;
using MemberGest.Models.Enum;
using MemberGest.Models.Extensions;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using Newtonsoft.Json;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace MemberGest.Services
{
    public class SeatService : ISeatService
    {
        private readonly ApplicationDbContext context;
        private readonly string NotificationUtility;
        private readonly HttpClient httpClient;
        public SeatService(ApplicationDbContext context, IConfiguration config, HttpClient httpClient)
        {
            this.context = context;
            this.NotificationUtility = config["NotificationUtility"];
            var handler = new HttpClientHandler
            {
                ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => true
            };


            this.httpClient = new HttpClient(handler);
        }
        public async Task<Seat?> ObtenerAsientoIdAsync(int id)
        {
            return await context.Seat.FindAsync(id);
        }

        public async Task<SeatDetailsDTO?> ObtenerAsientoDetallesIdAsync(int id)
        {
            Seat seat = await ObtenerAsientoIdAsync(id);
            SeatDetailsDTO? res = null;
            if (seat != null)
            {
                res = seat.ToDetailsDTO();
            }
            return res;
        }

        public async Task CrearAsientoAsync(SeatCreateDTO data, int UserCreatedId)
        {
            //Check if it is already in the system
            bool seatExists = await ExisteAsiento(data.LibraryId, data.FloorNum, data.RoomNum, data.RoomNum);
            if (seatExists)
            {
                throw new ArgumentException("El asiento ya está registrado.");
            }

            var seat = data.ToSeat();
            //Add the user who is creating the seat
            seat.UserCreatedId = UserCreatedId;
            seat.Remarks = "";


            context.Seat.Add(seat);
            await context.SaveChangesAsync();
        }

        public async Task<bool> EliminarAsientoAsync(int id, CurrentUserInfoAuth infoUser)
        {

            var seat = await ObtenerAsientoIdAsync(id);
            if (seat != null)
            {
                //If it is a gestor he only can remove his own libraries.
                if (infoUser.Role == RoleEnum.Gestor.ToString() && seat.UserCreatedId != infoUser.Id)
                {
                    throw new UnauthorizedAccessException("No tienes permisos para ello");
                }

                context.Remove(seat);
                await context.SaveChangesAsync();
                return true;

            }
            return false;

        }
        public async Task<PageResult<SeatDetailsDTO>> ObtenerAsientosAsync(SeatSearchParams pSearchParams)
        {
            var query = context.Seat
                .Include(s => s.Library)
                .AsQueryable();

            // Filter for the library
            if (pSearchParams.LibraryId.HasValue)
            {
                query = query.Where(p => p.LibraryId.Equals(pSearchParams.LibraryId));
            }

            //Filter for the status
            if (!string.IsNullOrEmpty(pSearchParams.Status) && EsValidoEstadoAsiento(pSearchParams.Status))
            {
                query = query.Where(u => u.Status.Contains(pSearchParams.Status));
            }

            // Filter for the floor
            if (pSearchParams.FloorNum.HasValue)
            {
                query = query.Where(p => p.FloorNum.Equals(pSearchParams.FloorNum));
            }

            // Filter for the room
            if (pSearchParams.RoomNum.HasValue)
            {
                query = query.Where(p => p.RoomNum.Equals(pSearchParams.RoomNum));
            }

            // Filter for the window
            if (pSearchParams.HasWindow.HasValue)
            {
                query = query.Where(p => p.HasWindow.Equals(pSearchParams.HasWindow));
            }

            // Filter for the socket
            if (pSearchParams.HasSocket.HasValue)
            {
                query = query.Where(p => p.HasSocket.Equals(pSearchParams.HasSocket));
            }

            // Filter for the wc near
            if (pSearchParams.IsWCNear.HasValue)
            {
                query = query.Where(p => p.IsWCNear.Equals(pSearchParams.IsWCNear));
            }

            // Filter for the library name
            if (!string.IsNullOrEmpty(pSearchParams.Library))
            {
                query = query.Where(p => p.Library.Name.Equals(pSearchParams.Library));
            }

            // Order by library 
            if (pSearchParams.OrderField?.ToLower() == "biblioteca")
            {
                query = pSearchParams.OrderBy?.ToLower() == "desc"
                    ? query.OrderByDescending(p => p.Library.Name)
                    : query.OrderBy(p => p.Library.Name);
            }

            // Order by floor
            if (pSearchParams.OrderField?.ToLower() == "planta")
            {
                query = pSearchParams.OrderBy?.ToLower() == "desc"
                    ? query.OrderByDescending(p => p.FloorNum)
                    : query.OrderBy(p => p.FloorNum);
            }

            // Order by room
            if (pSearchParams.OrderField?.ToLower() == "sala")
            {
                query = pSearchParams.OrderBy?.ToLower() == "desc"
                    ? query.OrderByDescending(p => p.RoomNum)
                    : query.OrderBy(p => p.RoomNum);
            }

            // Order by seatNum
            if (pSearchParams.OrderField?.ToLower() == "asiento")
            {
                query = pSearchParams.OrderBy?.ToLower() == "desc"
                    ? query.OrderByDescending(p => p.RoomNum)
                    : query.OrderBy(p => p.RoomNum);
            }

            //Get totalElements
            var totalItems = await query.CountAsync();

            //Get totalPages
            var totalPages = (int)Math.Ceiling(totalItems / (double)pSearchParams.PageSize);

            // Pages.
            query = query.Skip(pSearchParams.PageNum * pSearchParams.PageSize)
                         .Take(pSearchParams.PageSize);

            var list = await query.ToListAsync();

            // Convert to DTO
            List<SeatDetailsDTO> seats = list.Select(p => p.ToDetailsDTO()).ToList();
            return new PageResult<SeatDetailsDTO>
            {
                Items = seats,
                TotalItems = totalItems,
                TotalPages = totalPages,
                CurrentPage = pSearchParams.PageNum,
                PageSize = pSearchParams.PageSize
            };
        }
        //REVISAR
        public async Task<bool> ActualizarAsientoAsync(int id, SeatDetailsDTO data, CurrentUserInfoAuth infoUser)
        {
            Seat seat = await ObtenerAsientoIdAsync(id);
            if (seat != null)
            {
                //If it is a gestor he only can update his own libraries.
                if (infoUser.Role == RoleEnum.Gestor.ToString() && seat.UserCreatedId != infoUser.Id)
                {
                    throw new UnauthorizedAccessException("No tienes permisos para ello");
                }
                //Update values

                seat.Remarks = (data.Remarks.IsNullOrEmpty()) ? seat.Remarks : data.Remarks;
                seat.HasSocket = (seat.HasSocket.Equals(data.HasSocket)) ? seat.HasSocket : data.HasSocket;
                seat.HasWindow = (seat.HasWindow.Equals(data.HasWindow)) ? seat.HasWindow : data.HasWindow;
                seat.IsWCNear = (seat.IsWCNear.Equals(data.IsWCNear)) ? seat.IsWCNear : data.IsWCNear;
                if (EsValidoEstadoAsiento(data.Status))
                {
                    seat.Status = data.Status;
                }



                context.Entry(seat).State = EntityState.Modified;
                await context.SaveChangesAsync();
                return true;
            }
            return false;

        }

        public bool ExisteAsiento(int id)
        {
            return context.Seat.Any(e => e.Id == id);
        }

        public async Task<bool> ExisteAsiento(int libraryId, int floor, int room, int num)
        {
            return await context.Seat.AnyAsync(s => s.LibraryId == libraryId && s.SeatNum == num &&
                                                    s.FloorNum == floor && s.RoomNum == room);
        }

        private bool EsValidoEstadoAsiento(string status)
        {
            bool isvalid = false;
            if (!status.IsNullOrEmpty())
            {
                isvalid = status.Equals(SeatStatusEnum.Dañado.ToString()) || status.Equals(SeatStatusEnum.Disponible.ToString())
                           || status.Equals(SeatStatusEnum.Disponible.ToString());
            }
            return isvalid;
        }

        // RESERVAS
        public async Task<Reserve?> ObtenerReservaIdAsync(int id)
        {
            return await context.Reserve.Include(r => r.SeatReserved).ThenInclude(s => s.Library)
                                        .FirstOrDefaultAsync(r => r.Id == id);
        }

        public async Task<ReserveDetailsDTO?> ObtenerReservaDetallesIdAsync(int id)
        {
            Reserve reserve = await ObtenerReservaIdAsync(id);
            ReserveDetailsDTO? res = null;
            if (reserve != null)
            {
                res = reserve.ToDetailsDTO();
            }
            return res;
        }

        public async Task CrearReservaAsync(ReserveCreateDTO data, int userReservedId, string UserEmail)
        {
            //Check if it is already in the system
            bool reserveExists = await ExisteReserva(data.SeatReservedId, data.ReserveDate);
            if (reserveExists)
            {
                throw new ArgumentException("El asiento ya está reservado para esa fecha.");
            }
            //Check that this user has not already one reserve
            bool hasUserReserve = await ExisteReservaUsuarioDia(data.ReserveDate, userReservedId);
            if (hasUserReserve)
            {
                throw new ArgumentException("No puedes reservar, ya tienes una reserva para ese día.");
            }

            var reserve = data.ToReserve();
            //Add the user who is reserving the seat
            reserve.UserReservedId = userReservedId;


            context.Reserve.Add(reserve);
            await context.SaveChangesAsync();
            CreateEmail email = new CreateEmail()
            {
                RecipientEmail = UserEmail,
                Subject = "Nueva reserva en " + data.LibraryName,
                Content = "Se ha realizado una nueva reserva para el día " + data.ReserveDate + " en la biblioteca " + data.LibraryName +
                            ". En la planta " + data.FloorNum + " , sala " + data.RoomNum + " y el asiento " + data.SeatNum +
                            ". En el caso de que no acuda a la reserva sin cancelación previa, se te aplicará una penalización"
                            + "que puede afectar a tus futuras reservas. Te recomendamos anularla con antelación si no vas a asistir."
            };
            await EnviarNotificacion(email);
        }

        public async Task<bool> EliminarReservaAsync(int id, CurrentUserInfoAuth infoUser)
        {

            var reserve = await ObtenerReservaIdAsync(id);
            if (reserve != null)
            {
                //If it is a client he only can remove his own reserves.
                if (infoUser.Role == RoleEnum.Cliente.ToString() && reserve.UserReservedId != infoUser.Id)
                {
                    throw new UnauthorizedAccessException("No tienes permisos para ello");
                }

                //It only can be deleted if the date is not passed yet
                if (reserve.ReserveDate <= DateOnly.FromDateTime(DateTime.Today))
                {
                    throw new UnauthorizedAccessException("No puedes eliminar una reserva que ya ha pasado o que es de hoy");
                }

                context.Remove(reserve);
                await context.SaveChangesAsync();
                return true;

            }
            return false;

        }
        public async Task<PageResult<ReserveDetailsDTO>> ObtenerReservasAsync(ReserveSearchParams pSearchParams)
        {
            var query = context.Reserve
                .Include(r => r.SeatReserved).ThenInclude(s => s.Library).Include(r => r.UserReserved)
                .AsQueryable();

            // Filter for the library
            if (pSearchParams.LibraryId.HasValue)
            {
                query = query.Where(p => p.SeatReserved.LibraryId.Equals(pSearchParams.LibraryId));
            }

            // Filter for the library name
            if (!string.IsNullOrEmpty(pSearchParams.Library))
            {
                query = query.Where(p => p.SeatReserved.Library.Name.Equals(pSearchParams.Library));
            }

            //Filter for the status
            if (!string.IsNullOrEmpty(pSearchParams.Status) && EsValidoEstadoReserva(pSearchParams.Status))
            {
                query = query.Where(u => u.Status.Contains(pSearchParams.Status));
            }

            //Filter for the user
            if (pSearchParams.UserId.HasValue)
            {
                query = query.Where(p => p.UserReservedId.Equals(pSearchParams.UserId));
            }

            //Filter for the username
            if (!string.IsNullOrEmpty(pSearchParams.Username))
            {
                query = query.Where(p => p.UserReserved.Name.Equals(pSearchParams.Username));
            }

            //Filter for the floor
            if (pSearchParams.Floor.HasValue)
            {
                query = query.Where(p => p.SeatReserved.FloorNum.Equals(pSearchParams.Floor));
            }

            //Filter for the reserveDate
            if (pSearchParams.ReserveDate.HasValue)
            {
                query = query.Where(p => p.ReserveDate.Equals(pSearchParams.ReserveDate));
            }



            // Order by library 
            if (pSearchParams.OrderField?.ToLower() == "fecha")
            {
                query = pSearchParams.OrderBy?.ToLower() == "desc"
                    ? query.OrderByDescending(p => p.ReserveDate)
                    : query.OrderBy(p => p.ReserveDate);
            }

            // Order by floor
            if (pSearchParams.OrderField?.ToLower() == "biblioteca")
            {
                query = pSearchParams.OrderBy?.ToLower() == "desc"
                    ? query.OrderByDescending(p => p.SeatReserved.Library)
                    : query.OrderBy(p => p.SeatReserved.Library);
            }

            //Get totalElements
            var totalItems = await query.CountAsync();

            //Get totalPages
            var totalPages = (int)Math.Ceiling(totalItems / (double)pSearchParams.PageSize);

            // Pages.
            query = query.Skip(pSearchParams.PageNum * pSearchParams.PageSize)
                         .Take(pSearchParams.PageSize);

            var list = await query.ToListAsync();

            // Convert to DTO
            List<ReserveDetailsDTO> reserves = list.Select(p => p.ToDetailsDTO()).ToList();
            return new PageResult<ReserveDetailsDTO>
            {
                Items = reserves,
                TotalItems = totalItems,
                TotalPages = totalPages,
                CurrentPage = pSearchParams.PageNum,
                PageSize = pSearchParams.PageSize
            };
        }

        public async Task<bool> ActualizarReservaAsync(int id, ReserveDetailsDTO data, CurrentUserInfoAuth infoUser)
        {
            Reserve reserve = await ObtenerReservaIdAsync(id);
            if (reserve != null)
            {
                //If it is a client he only can update his own reserves.
                if (infoUser.Role == RoleEnum.Cliente.ToString() && reserve.UserReservedId != infoUser.Id)
                {
                    throw new UnauthorizedAccessException("No tienes permisos para ello");
                }
                //It only can be updated if the date is not passed yet
                if (reserve.ReserveDate < DateOnly.FromDateTime(DateTime.Today))
                {
                    throw new UnauthorizedAccessException("No puedes modificar una reserva que ya ha pasado o que es de hoy");
                }
                // If is the same date, it only can change the status
                if (reserve.ReserveDate == DateOnly.FromDateTime(DateTime.Today))
                {
                    if (EsValidoEstadoReserva(data.Status))
                    {
                        reserve.Status = data.Status;
                    }
                }
                else
                {
                    reserve.ReserveDate = (!data.ReserveDate.HasValue) ? reserve.ReserveDate : data.ReserveDate.Value;
                    reserve.SeatReservedId = (!data.SeatReservedId.HasValue) ? reserve.SeatReservedId : data.SeatReservedId.Value;
                }


                context.Entry(reserve).State = EntityState.Modified;
                await context.SaveChangesAsync();
                return true;
            }
            return false;

        }

        public bool ExisteReserva(int id)
        {
            return context.Reserve.Any(e => e.Id == id);
        }

        public async Task<bool> ExisteReserva(int seatId, DateOnly date)
        {
            return await context.Reserve.AnyAsync(s => s.SeatReservedId == seatId && s.ReserveDate == date);
        }

        public async Task<bool> ExisteReservaUsuarioDia(DateOnly date, int userID)
        {
            return await context.Reserve.AnyAsync(s => s.ReserveDate == date && userID == s.UserReservedId);
        }

        private bool EsValidoEstadoReserva(string status)
        {
            bool isvalid = false;
            if (!status.IsNullOrEmpty())
            {
                isvalid = status.Equals(ReserveStatusEnum.Asiste.ToString()) || status.Equals(ReserveStatusEnum.Ausencia.ToString());
            }
            return isvalid;
        }

        private async Task EnviarNotificacion(CreateEmail email)
        {
            var response = await httpClient.PostAsJsonAsync(this.NotificationUtility, email);
            if (!response.IsSuccessStatusCode)
            {
                throw new Exception(response.StatusCode.ToString());
            }

        }
    }
}