﻿using MemberGest.Models;

namespace MemberGest.Services
{
    public interface IConfigService
    {
        Task<Configuration?> ObtenerConfiguracionAsync();
    }
}
