﻿using MemberGest.Models;

namespace MemberGest.Services
{
    public interface ISeatService
    {
        Task<SeatDetailsDTO?> ObtenerAsientoDetallesIdAsync(int id);
        Task<PageResult<SeatDetailsDTO>> ObtenerAsientosAsync(SeatSearchParams pSearchParams);
        Task CrearAsientoAsync(SeatCreateDTO data, int UserCreatedId);
        Task<bool> ActualizarAsientoAsync(int id, SeatDetailsDTO data, CurrentUserInfoAuth infoUser);
        Task<bool> EliminarAsientoAsync(int id, CurrentUserInfoAuth infoUser);
        bool ExisteAsiento(int id);

        Task<ReserveDetailsDTO?> ObtenerReservaDetallesIdAsync(int id);
        Task<PageResult<ReserveDetailsDTO>> ObtenerReservasAsync(ReserveSearchParams pSearchParams);
        Task CrearReservaAsync(ReserveCreateDTO data, int UserCreatedId, string UserEmail);
        Task<bool> ActualizarReservaAsync(int id, ReserveDetailsDTO data, CurrentUserInfoAuth infoUser);
        Task<bool> EliminarReservaAsync(int id, CurrentUserInfoAuth infoUser);
        bool ExisteReserva(int id);
    }
}
