﻿using MemberGest.Models;

namespace MemberGest.Services
{
    public interface ILendingService
    {
        Task<LendingDetailsDTO?> ObtenerPrestamoDetallesIdAsync(int id);
        Task<PageResult<LendingDetailsDTO>> ObtenerPrestamosAsync(LendingSearchParams pSearchParams);
        Task CrearPrestamoAsync(LendingCreateDTO data, int UserCreatedId);
        Task<bool> ActualizarPrestamoAsync(int id, LendingDetailsDTO data, CurrentUserInfoAuth infoUser);
        Task<bool> EliminarPrestamoAsync(int id, CurrentUserInfoAuth infoUser);
        bool ExistePrestamo(int id);
    }
}
