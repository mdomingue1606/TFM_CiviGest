﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using NotificationUtility.Context;
using NotificationUtility.Models;
using NotificationUtility.Services;

namespace NotificationUtility.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class NotificationController : ControllerBase
    {
        private readonly IEmailService emailService;

        public NotificationController(IEmailService emailService)
        {
            this.emailService = emailService;
        }

        // POST: api/SentEmails
        [HttpPost]
        public async Task<IActionResult> PostSentEmail(CreateEmail sentEmail)
        {
            await emailService.SendEmailAsync(sentEmail);
            
            return Ok("Email enviado");
            
        }

    }
}
