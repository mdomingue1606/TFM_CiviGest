﻿using Microsoft.EntityFrameworkCore;
using NotificationUtility.Models;
using System.Text.Json;

namespace NotificationUtility.Context
{
    public class ApplicationDbContext: DbContext
    {
        public DbSet<Configuration> Configuration { get; set; }
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
       : base(options)
        {
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Configuration>()
                .Property(c => c.Audience)
                .HasConversion(
                    v => SerializeList(v),
                    v => DeserializeList(v));

            //Relation between User and USerRole
            modelBuilder.Entity<User>()
                .HasOne(u => u.Role)
                .WithMany()
                .HasForeignKey(u => u.UserRoleId)
                .OnDelete(DeleteBehavior.Restrict);

            

        }
        private string SerializeList(List<string> list)
        {
            return JsonSerializer.Serialize(list);
        }

        // Deserialize Method
        private List<string> DeserializeList(string json)
        {
            Console.WriteLine(json);
            return JsonSerializer.Deserialize<List<string>>(json);
        }
    }
}
