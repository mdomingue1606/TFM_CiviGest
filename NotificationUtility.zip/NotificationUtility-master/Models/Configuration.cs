﻿namespace NotificationUtility.Models
{
    public class Configuration
    {
        public int Id { get; set; }
        public string Key { get; set; }
        public string Issuer { get; set; }
        public List<string> Audience { get; set; }
        public string UserServiceURL { get; set; }
    }
}
