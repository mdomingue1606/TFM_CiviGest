﻿using NotificationUtility.Models;

namespace NotificationUtility.Services
{
    public interface ICurrentInfoAuthService
    {
        CurrentUserInfoAuth ObtenerInfoAuth(HttpRequest request);
    }
}
