﻿using System.Net;
using System.Net.Mail;
using NotificationUtility.Context;
using NotificationUtility.Models;
using SendGrid;
using SendGrid.Helpers.Mail;

namespace NotificationUtility.Services
{
    public class EmailService : IEmailService
    {
        private readonly ApplicationDbContext context;
        private readonly string apiKey;

        public EmailService(ApplicationDbContext context, IConfiguration conf)
        {
            this.context = context;
            this.apiKey = conf["ApiKey"];
        }

        public async Task<bool> SendEmailAsync(CreateEmail sentEmail)
        {
            var client = new SendGridClient(apiKey);
            var from = new EmailAddress("civigest-tfm@outlook.com");
            var to = new EmailAddress(sentEmail.RecipientEmail);
            var msg = MailHelper.CreateSingleEmail(from, to, sentEmail.Subject, sentEmail.Content, sentEmail.Content);

            var res  = await client.SendEmailAsync(msg);
            if (!res.IsSuccessStatusCode)
            {
                throw new Exception(res.StatusCode.ToString());
            }
            return true;
        }
    }
}
