﻿using NotificationUtility.Models;

namespace NotificationUtility.Services
{
    public interface IEmailService
    {
        Task<bool> SendEmailAsync(CreateEmail sentEmail);
    }
}
