﻿using NotificationUtility.Context;
using NotificationUtility.Models;
using Microsoft.EntityFrameworkCore;

namespace NotificationUtility.Services
{
    public class ConfigService : IConfigService
    {
        private readonly ApplicationDbContext context;
        public ConfigService(ApplicationDbContext context)
        {
            this.context = context;
        }

        public async Task<Configuration?> ObtenerConfiguracionAsync()
        {

            return await context.Configuration.FirstOrDefaultAsync();
        }
    }
}
