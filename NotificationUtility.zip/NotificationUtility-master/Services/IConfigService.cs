﻿using NotificationUtility.Models;

namespace NotificationUtility.Services
{
    public interface IConfigService
    {
        Task<Configuration?> ObtenerConfiguracionAsync();
    }
}
