export interface CreateLending {
    lendingInitDate: string;
    copyBookId: string;
}

export interface LendingDetails{
    lendingInitDate: string;
    lendingFinishDate: string;
    status: string;
    bookId: number;
    userReservedId: string;
    id: number;
    usernameReservedBy?: string;
    book?: string;
    copyBookId: number;
    library: string;
}

export interface LendingSearchParams{
    npag: number;       
    nelem: number;
    status?: string;
    book?: string;
    copyBookId?: number;
    userName?: string;
    userId?:number;
    orderBy?: string;
    orderField?: string;
}

export enum LendingStatus {
    request="Solicitado",
    lending="Prestado",
    returned="Devuelto"
}