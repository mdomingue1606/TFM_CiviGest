import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LendinglistComponent } from './lendinglist.component';

describe('LendinglistComponent', () => {
  let component: LendinglistComponent;
  let fixture: ComponentFixture<LendinglistComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [LendinglistComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(LendinglistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
