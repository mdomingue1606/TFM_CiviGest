import { AfterViewInit, Component, OnInit, ViewChild } from '@angular/core';
import { SearchBarComponent } from '../../shared/search-bar/search-bar.component';
import { MatInputModule } from '@angular/material/input';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSort, MatSortModule, Sort } from '@angular/material/sort';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatPaginator, MatPaginatorIntl, MatPaginatorModule } from '@angular/material/paginator';
import { MatTableModule } from '@angular/material/table';
import { CommonModule } from '@angular/common';
import { getSpanishPaginatorIntl } from '../../shared/spanish-paginator-intl';
import { LendingDetails, LendingSearchParams, LendingStatus } from '../../models/lending.model';
import { SearchFilterDefinition } from '../../models/search-filter.model';
import { PagedResponse } from '../../models/paged-response.model';
import { LendingService } from '../../services/lending.service';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { UserService } from '../../services/user.service';
import { Role } from '../../models/user.model';
import { ConfirmDialogComponent } from '../../shared/confirm-dialog/confirm-dialog.component';
import { CopybookService } from '../../services/copybook.service';
import { CopyBookStatus } from '../../models/copybook.model';

@Component({
  selector: 'app-lendinglist',
  imports: [CommonModule, MatTableModule, MatPaginatorModule, MatButtonModule, MatIconModule, MatSortModule, MatProgressSpinnerModule, MatInputModule, SearchBarComponent],
  providers: [ { provide: MatPaginatorIntl, useValue: getSpanishPaginatorIntl() } ],
  templateUrl: './lendinglist.component.html',
  styleUrl: './lendinglist.component.css'
})
export class LendinglistComponent implements OnInit, AfterViewInit{

  displayedColumns: string[] = [];
  dataSource: LendingDetails[] = [];
  usernameCache: Map<string, string> = new Map();
  isClient = true;
  isLogged = false;
  title='Listado de préstamos';
  libraryName = '';
  filters: SearchFilterDefinition[] = [];

  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort, { static: false }) sort!: MatSort;
  @ViewChild(SearchBarComponent) searchBarComponent!: SearchBarComponent;

  searchParams: LendingSearchParams={
    npag:0,
    nelem:10
  };

  pagedResponse!: PagedResponse<LendingDetails>;
  loading: boolean = false;
  private lastSortRef: MatSort | null = null;

  constructor(private lendingService: LendingService, private dialog: MatDialog, private authService: AuthService,
              private snackBar: MatSnackBar, private router:Router, private userService: UserService,
              private activatedRoute: ActivatedRoute, private copybookService: CopybookService) {}

  getListLending(){
    this.loading = true;

    this.lendingService.getLendingList(this.searchParams).subscribe({
      next: (response) => {
        this.pagedResponse = response;
        this.dataSource.length = 0;
        this.dataSource.push(...response.items);
        this.dataSource = [...this.dataSource];
        this.loadUsernameReserveGuest(this.dataSource)
        console.log(this.dataSource);
        this.loading = false;

        if (this.paginator) {
          this.paginator.length = response.totalItems;
        }
        console.log(this.searchParams);
      },
      error: () => {
        this.loading = false;
      },
    });
  }

  ngOnInit(): void {
    this.filters = this.lendingService.getFilterLendingList();

    if (typeof window !== 'undefined' && window.localStorage) {
      this.authService.userStatus$.subscribe(() => {
        this.isClient = this.checkIfClientUser();
        this.isLogged = this.checkIfIsLogged();
        this.displayedColumns = this.getDisplayedColumns();
      });
      this.isClient = this.checkIfClientUser();
      this.isLogged = this.checkIfIsLogged();
      this.displayedColumns = this.getDisplayedColumns();
    }

    this.activatedRoute.params.subscribe(params => {
      const userIdParam = this.activatedRoute.snapshot.queryParamMap.get('userId');
      const userId = userIdParam !== null ? +userIdParam : NaN;
      if(!isNaN(userId)){
        this.getUserFromParams(userId);
      }
      this.getListLending();
    })
      
  }

  getDisplayedColumns(): string[]{
    const base = ['library', 'book', 'copybook', 'dateInit', 'dateEnd', 'status', 'actions']
    if(this.isLogged && !this.isClient){
      const index=5;
      this.displayedColumns.splice(index,0,'username')
    }
    return base
  }

  ngAfterViewInit(): void {
    setTimeout(() => {
      this.getDisplayedColumns();
    });
    
     this.sort.sortChange.subscribe((sort: Sort) => {
      const fieldMap: Record<string, string> = {
        dateInit: 'fechaIni',
        dateEnd: 'fechaFin',
      };

      const mappedField = fieldMap[sort.active];
      if (!mappedField || !sort.direction) {
        delete this.searchParams.orderField;
        delete this.searchParams.orderBy;
      } else {
        this.searchParams.orderField = mappedField;
        this.searchParams.orderBy = sort.direction;
      }

      // Establecemos la página a la primera cuando cambia el orden
      this.searchParams.npag = 0;
      
      // Llamamos a la función para obtener los usuarios con el nuevo orden
      this.getListLending();
      
    });
    
  }

  ngAfterViewChecked(): void {
    // Verificamos si `matSort` está disponible
    if (this.sort && this.sort !== this.lastSortRef) {
      this.lastSortRef = this.sort;
      this.sort.sortChange.subscribe((sort: Sort) => {
        const fieldMap: Record<string, string> = {
        dateInit: 'fechaIni',
        dateEnd: 'fechaFin',
      };

        const mappedField = fieldMap[sort.active];
        if (!mappedField || !sort.direction) {
          delete this.searchParams.orderField;
          delete this.searchParams.orderBy;
        } else {
          this.searchParams.orderField = mappedField;
          this.searchParams.orderBy = sort.direction;
        }

        this.searchParams.npag = 0; // Reinicia a la primera página
        this.getListLending();
      });
    }
  }

  checkIfClientUser(): boolean{
    const userrole= this.authService.getRoleFromToken();
    if(userrole && (userrole === Role.admin || userrole === Role.gestor)) return false;
    return true;
  }
  
  checkIfIsLogged(): boolean{
    const userid= this.authService.getUserIdFromToken();
    if(userid) return true;
    return false;
  }

  applyFilter(event: {text:string; filters: {[key:string]:any}}){
    const { text, filters } = event;

    this.searchParams.book = text?.trim().toLowerCase() || '';
    this.searchParams.userName = filters['user_search'] || '';
    this.searchParams.status = filters['status_search'] || '';
    this.searchParams.npag=0;
    this.getListLending();
  }

  getUserFromParams(userId:number){
    //Filtramos por el usuario directamente.
    this.searchParams.userId = userId;
    //Cambiamos el título porque pueden ser sus propios prestamos
    this.userService.getUser(userId+'').subscribe({
      next:(u) =>{
        this.title = (this.checkIfClientUser()) ? "Mis préstamos" : "Listado de préstamos"
        this.searchBarComponent.filters['username_search'] = u.name;
      },
      error: (err) => {
        console.error('Error al obtener usuario:', err);
        this.snackBar.open('Ha ocurrido un error.', 'Cerrar', {
          duration: 3000,
          panelClass: ['snackbar-error']
        });
        this.router.navigate(['/']);
      }
    });
    
  }

  loadUsernameReserveGuest(reserves: LendingDetails[]){
    reserves.forEach(element => {
      this.userService.getUser(element.userReservedId).subscribe({
        next:(u) =>{
          element.usernameReservedBy= u.name + " " + u.surname;
        },
        error: (err) => {
          element.usernameReservedBy="Anónimo"
        }
      });
      
    });
  }

  onPageChange(event: any): void {
    this.searchParams.nelem = event.pageSize;
    this.searchParams.npag = event.pageIndex;
    
    this.getListLending();
  }

  markLending(lending: LendingDetails){

    if(!this.checkValidStatus(lending)){
      this.snackBar.open('No puedes marcar un préstamo que ya se ha entregado.', 'Cerrar', { duration: 3000, panelClass: ['snackbar-error'] });
    }
    else if(!this.checkIfCanMark(lending)){
      this.snackBar.open('No puedes marcar este préstamo', 'Cerrar', { duration: 3000, panelClass: ['snackbar-error'] });
    }
    else {
      const dialogRef = this.dialog.open(ConfirmDialogComponent, {
        width: '350px',
        data: {
          title: '¿Estás seguro?',
          message: 'Vas a marcar que el usuario ' + lending.usernameReservedBy + ' ha recogido el ejemplar. Esta acción no se puede deshacer.'
        }
      });

      dialogRef.afterClosed().subscribe(result => {
        if (result === true) {
          if(lending.status === LendingStatus.request)
            lending.status = LendingStatus.lending;
          else if(lending.status === LendingStatus.lending){
            lending.status = LendingStatus.returned;
            lending.lendingFinishDate =  new Date().toISOString().split('T')[0]
          }
          this.lendingService.updateLending(lending.id.toString(), lending).subscribe({
            next:() =>{
              if(lending.status === LendingStatus.returned){
                let msg = "Préstamo actualizado";
                this.updateStatusCopyBook(lending, msg);
              }
              else{
                this.snackBar.open('Préstamo actualizado', 'Cerrar', {
                  duration: 5000,
                  panelClass: ['snackbar-success']
                });
                this.getListLending();
              }
            },
            error: (err) => {
              console.error('Error al actualizar el préstamo:', err);
              this.snackBar.open('Error al actualizar el préstamo', 'Cerrar', {
                duration: 3000,
                panelClass: ['snackbar-error']
              });
            }
          })
        }
      });
    }

  }

  deleteLending(lending: LendingDetails){
    if(lending.status !== LendingStatus.request){
      this.snackBar.open('No puedes borrar este préstamo.', 'Cerrar', { duration: 3000, panelClass: ['snackbar-error'] });
    }
    else if(!this.checkIfCanEditOrDelete(lending)){
      this.snackBar.open('No puedes eliminar esta reseva', 'Cerrar', { duration: 3000, panelClass: ['snackbar-error'] });
    }
    else {
      const dialogRef = this.dialog.open(ConfirmDialogComponent, {
        width: '350px',
        data: {
          title: '¿Estás seguro?',
          message: 'Vas a eliminar a este préstamo del sistema. Esta acción no se puede deshacer.'
        }
      });

      dialogRef.afterClosed().subscribe(result => {
        if (result === true) {
          this.lendingService.deleteLending(lending.id.toString()).subscribe({
            next:() =>{
              this.updateStatusCopyBook(lending, "Préstamo eliminado");
              /*this.snackBar.open('Préstamo eliminado', 'Cerrar', {
                duration: 5000,
                panelClass: ['snackbar-success']
              });
              this.getListLending();*/
            },
            error: (err) => {
              console.error('Error al borrar el préstamo:', err);
              this.snackBar.open('Error al borrar el préstamo. '+ err.error, 'Cerrar', {
                duration: 3000,
                panelClass: ['snackbar-error']
              });
            }
          })
        }
      });
    }

  }

  updateStatusCopyBook(lending: LendingDetails, msg: string){  
    this.copybookService.getCopyBook(lending.copyBookId+'').subscribe({
      next: (response) => {
        response.status = CopyBookStatus.available;
        this.copybookService.updateCopyBook(response.id+'', response).subscribe({
          next: (response) => {
            this.snackBar.open(msg, 'Cerrar', {
            duration: 5000,
            panelClass: ['snackbar-success']
            });
            this.getListLending();
          },
          error:(err) => {
            console.error('Error al actualizar el ejemplar:', err);
            this.snackBar.open('Error al realizar la reserva. ', 'Cerrar', {
              duration: 3000,
              panelClass: ['snackbar-error']
            });
          }
        })
      }
    })    
  }

  checkIfCanEditOrDelete(lending: LendingDetails): boolean{
    if(this.isLogged){
      const userrole= this.authService.getRoleFromToken();
      const userId = this.authService.getUserIdFromToken();
      const canDelete = lending.status === LendingStatus.request;

      if(userrole && (userrole === Role.admin || userrole === Role.gestor) && canDelete) return true;
      else if(userId && userId === lending.userReservedId +'' && canDelete) return true;
      else return false;
    }
    else return false;
  }

  checkIfCanMark(lending: LendingDetails): boolean{
    if(this.isLogged && this.checkValidStatus(lending)){
      const userrole= this.authService.getRoleFromToken();

      if(userrole && (userrole === Role.admin || userrole === Role.gestor)) return true;
      else return false;
    }
    else return false;
  }

  checkValidStatus(lending:LendingDetails): boolean{
    return lending.status === LendingStatus.request || lending.status === LendingStatus.lending;
  }

  get totalItems(): number {
    return this.pagedResponse?.totalItems ?? 0;
  }

  get pageSize(): number {
    return this.pagedResponse?.pageSize ?? this.searchParams.nelem;
  }

}
