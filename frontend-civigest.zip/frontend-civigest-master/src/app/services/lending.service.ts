import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { CreateLending, LendingDetails, LendingSearchParams, LendingStatus } from '../models/lending.model';
import { ApiBaseUrls } from '../config/api-endpoints';
import { PagedResponse } from '../models/paged-response.model';
import { SearchFilterDefinition } from '../models/search-filter.model';

@Injectable({
  providedIn: 'root'
})
export class LendingService {

  constructor(private http: HttpClient) { }

   create(lending: CreateLending): Observable<any> {
    const token = localStorage.getItem('token');
    const headers = new HttpHeaders({
      'Authorization' : `Bearer ${token}`
    });
    return this.http.post(`${ApiBaseUrls.lendings}`, lending, {headers});
  }

  getSeat(id: string): Observable<any> {
    const token = localStorage.getItem('token');
    const headers = new HttpHeaders({
      'Authorization' : `Bearer ${token}`
    });
    return this.http.get(`${ApiBaseUrls.lendings}/${id}`, {headers});
  }

  updateLending(id:string, lending: LendingDetails): Observable<any>{
    const token = localStorage.getItem('token');
    const headers = new HttpHeaders({
      'Authorization' : `Bearer ${token}`
    });
    return this.http.put(`${ApiBaseUrls.lendings}/${id}`, lending, {headers});
  }

  deleteLending(id:string): Observable<any>{
    const token = localStorage.getItem('token');
    const headers = new HttpHeaders({
      'Authorization' : `Bearer ${token}`
    });
    return this.http.delete(`${ApiBaseUrls.lendings}/${id}`, {headers});
  }

  getLendingList(request: LendingSearchParams): Observable<PagedResponse<LendingDetails>> {
    const token = localStorage.getItem('token');
    const headers = new HttpHeaders({
      'Authorization' : `Bearer ${token}`
    });
    
    let params = new HttpParams() 
      .set('npag', request.npag.toString())
      .set('nelem', request.nelem.toString());

    if (request.copyBookId) params = params.set('ejemplarId', request.copyBookId);
    if (request.status) params = params.set('estado', request.status);
    if (request.userName) params = params.set('usuario', request.userName);
    if (request.userId) params = params.set('usuarioId', request.userId);
    if (request.book) params = params.set('libro', request.book);

    if (request.orderBy) params = params.set('orden', request.orderBy);
    if (request.orderField) params = params.set('campoOrden', request.orderField);

    return this.http.get<PagedResponse<LendingDetails>>(`${ApiBaseUrls.lendings}/`, {params: params, headers: headers });
  }

  getFilterLendingList(): SearchFilterDefinition[] {
      let filters: SearchFilterDefinition[] =[
        {//Status
          id:'status_search',
          label:'Estado',
          type:'select',
          options: Object.values(LendingStatus),
          placeholder:''
        },
        {//user
          id:'user_search',
          label:'',
          placeholder:'Buscar por usuario...',
          type:'text',
        }
      ];
      return filters;
      
    }
}
