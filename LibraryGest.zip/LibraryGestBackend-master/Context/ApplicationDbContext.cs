﻿using LibraryGest.Models;
using System.Text.Json;
using Microsoft.DotNet.Scaffolding.Shared;
using Microsoft.EntityFrameworkCore;

namespace LibraryGest.Context
{
    public class ApplicationDbContext: DbContext
    {
        public DbSet<Library> Library { get; set; }
        public DbSet<Configuration> Configuration { get; set; }
        public DbSet<Book> Book { get; set; }
        public DbSet<CopyBook> CopyBook { get; set; }
        public DbSet<Author> Author { get; set; }
        public DbSet<AuthorBook> AuthorBook { get; set; }
        public DbSet<Archive> Archive { get; set; }
        public DbSet<AuthorArchive> AuthorArchive { get; set; }

        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
       : base(options)
        {
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Configuration>()
                .Property(c => c.Audience)
                .HasConversion(
                    v => SerializeList(v),
                    v => DeserializeList(v));

            //Relation between User and USerRole
            modelBuilder.Entity<User>()
                .HasOne(u => u.Role)
                .WithMany()
                .HasForeignKey(u => u.UserRoleId)
                .OnDelete(DeleteBehavior.Restrict);

            //Unique values for email and CIF Library
            modelBuilder.Entity<Library>()
                .HasIndex(p => p.Email)
                .IsUnique();
            modelBuilder.Entity<Library>()
                .HasIndex(p => p.CIF)
                .IsUnique();

            //Unique value for ISBN Book
            modelBuilder.Entity<Book>()
               .HasIndex(p => p.ISBN)
               .IsUnique();

            //Relation between Library and User
            modelBuilder.Entity<Library>()
                .HasOne(p => p.UserCreated)
                .WithMany()
                .HasForeignKey(p => p.UserCreatedId)
                .OnDelete(DeleteBehavior.Restrict);

            //Type of the Library photo
            modelBuilder.Entity<Library>()
                .Property(l => l.Photo)
                .HasColumnType("LONGBLOB");

            //Relation between Book and User
            modelBuilder.Entity<Book>()
                .HasOne(p => p.UserCreated)
                .WithMany()
                .HasForeignKey(p => p.UserCreatedId)
                .OnDelete(DeleteBehavior.Restrict);

            //Type of the book photo
            modelBuilder.Entity<Book>()
                .Property(l => l.Photo)
                .HasColumnType("LONGBLOB");

            //Relation between CopyBook and rest
            modelBuilder.Entity<CopyBook>()
                .HasOne(p => p.UserCreated)
                .WithMany()
                .HasForeignKey(p => p.UserCreatedId)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<CopyBook>()
                .HasOne(p => p.Book)
                .WithMany()
                .HasForeignKey(p => p.BookId)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<CopyBook>()
                .HasOne(p => p.Library)
                .WithMany()
                .HasForeignKey(p => p.LibraryId)
                .OnDelete(DeleteBehavior.Restrict);

            //Relation between authors and books
            modelBuilder.Entity<AuthorBook>()
                .HasKey(ab => new { ab.BookId, ab.AuthorId });
                
            modelBuilder.Entity<AuthorBook>()
                .HasOne(ab => ab.Author)
                .WithMany(a => a.AuthorBooks)
                .HasForeignKey(ab => ab.AuthorId);

            modelBuilder.Entity<AuthorBook>()
                .HasOne(ab => ab.Book)
                .WithMany(a => a.AuthorBooks)
                .HasForeignKey(ab => ab.BookId);

            //Relation between archives and authors
            modelBuilder.Entity<AuthorArchive>()
                .HasKey(ab => new { ab.ArchiveId, ab.AuthorId });

            modelBuilder.Entity<AuthorArchive>()
                .HasOne(ab => ab.Author)
                .WithMany(a => a.AuthorArchives)
                .HasForeignKey(ab => ab.AuthorId);

            modelBuilder.Entity<AuthorArchive>()
                .HasOne(ab => ab.Archive)
                .WithMany(a => a.AuthorArchives)
                .HasForeignKey(ab => ab.ArchiveId);

            //Relation between Archive and User
            modelBuilder.Entity<Archive>()
                .HasOne(p => p.UserCreated)
                .WithMany()
                .HasForeignKey(p => p.UserCreatedId)
                .OnDelete(DeleteBehavior.Restrict);

            //Type of the book photo
            modelBuilder.Entity<Archive>()
                .Property(l => l.File)
                .HasColumnType("LONGBLOB");
        }
        private string SerializeList(List<string> list)
        {
            return JsonSerializer.Serialize(list);
        }

        // Deserialize Method
        private List<string> DeserializeList(string json)
        {
            Console.WriteLine(json);
            return JsonSerializer.Deserialize<List<string>>(json);
        }

    }
}
