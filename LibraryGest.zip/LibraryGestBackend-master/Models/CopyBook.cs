﻿namespace LibraryGest.Models
{
    public class CopyBook
    {
        public int Id { get; set; }
        public string Status { get; set; }
        public string Ubication { get; set; }
        public string EditionNum { get; set; }
        public DateOnly PurchaseDate { get; set; }
        public string Remarks { get; set; }

        public int UserCreatedId { get; set; }
        public User UserCreated { get; set; }

        public int BookId { get; set; }
        public Book Book { get; set; }

        public int LibraryId { get; set; }
        public Library Library { get; set; }
    }

    public class CopyBookCreateDTO
    {
        public string Ubication { get; set; }
        public string EditionNum { get; set; }
        public DateOnly PurchaseDate { get; set; }
        public string Remarks { get; set; }
        public int BookId { get; set; }
        public int LibraryId { get; set; }
    }

    public class CopyBookDetailsDTO
    {
        public string Status { get; set; }
        public string Ubication { get; set; }
        public string EditionNum { get; set; }
        public DateOnly PurchaseDate { get; set; }
        public string Remarks { get; set; }
        public int UserCreatedId { get; set; }
        public int Id { get; set; }
        public int BookId { get; set; }
        public int LibraryId { get; set; }
    }

    public class CopyBookSearchParams //REVISAR
    {
        public int PageNum { get; set; } = 0;
        public int PageSize { get; set; } = 10;
        public string? Library { get; set; }
        public string? Book { get; set; }
        public int? BookId { get; set; }
        public int? LibraryId { get; set; }
        public string? Status { get; set; }
        public string? OrderBy { get; set; }
        public string? OrderField { get; set; }
    }
}
