﻿using System.Security.Policy;

namespace LibraryGest.Models
{
    public class Library
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string CIF { get; set; }
        public string PhoneNumber { get; set; }
        public string Address { get; set; }
        public string Description { get; set; }
        public byte[] Photo {  get; set; }
        public string PhotoMimeType { get; set; }
        public int FloorNumbers { get; set; }

        public int UserCreatedId { get; set; }
        public User UserCreated { get; set; }

    }

    public class LibraryCreateDTO
    {
        public string Name { get; set; }
        public string Email { get; set; }
        public string Description { get; set; }
        public string CIF { get; set; }
        public string PhoneNumber { get; set; }
        public string Address { get; set; }
        public string Photo { get; set; }
        public string PhotoMimeType { get; set; }
        public int FloorNumbers { get; set; }
    }

    public class LibraryDetailsDTO
    {
        public string Name { get; set; }
        public string Email { get; set; }
        public string Description { get; set; }
        public string CIF { get; set; }
        public string PhoneNumber { get; set; }
        public string Address { get; set; }
        public int UserCreatedId { get; set; }
        public int Id { get; set; }
        public string Photo { get; set; }
        public string PhotoMimeType { get; set; }
        public int FloorNumbers { get; set; }
    }

    public class LibrarySearchParams
    {
        public int PageNum { get; set; } = 0;
        public int PageSize { get; set; } = 10;
        public string? Name { get; set; }
        public string? OrderBy { get; set; }
        public string? OrderField { get; set; }
    }

}
