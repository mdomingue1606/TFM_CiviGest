﻿namespace LibraryGest.Models.Extensions
{
    public static class BookExtensions
    {
        public static BookDetailsDTO ToDetailsDTO(this Book book)
        {
            return new BookDetailsDTO
            {
                ISBN = book.ISBN,
                Title = book.Title,
                PagNum = book.PagNum,
                PublicationDate = book.PublicationDate,
                Summary = book.Summary,
                UserCreatedId = book.UserCreatedId,
                Publisher = book.Publisher,
                Id = book.Id,
                Photo = book.Photo != null ? Convert.ToBase64String(book.Photo) : null,
                PhotoMimeType = book.PhotoMimeType,
                AuthorIds = book.AuthorBooks?
                    .Select(ab => new AuthorDetailsDTO
                    {
                        Id = ab.Author.Id,
                        NameSurname = ab.Author.NameSurname
                    }).ToList()

            };
        }

        public static Book ToBook(this BookCreateDTO book)
        {
            return new Book
            {
                ISBN = book.ISBN,
                PagNum = book.PagNum,
                Summary = book.Summary,
                PublicationDate = book.PublicationDate,
                Title = book.Title,
                Photo = string.IsNullOrWhiteSpace(book.Photo) ? null : Convert.FromBase64String(book.Photo),
                PhotoMimeType = book.PhotoMimeType,
                Publisher = book.Publisher
            };
        }
    }
}
