﻿namespace LibraryGest.Models.Extensions
{
    public static class CopyBookExtension
    {
        public static CopyBookDetailsDTO ToDetailsDTO(this CopyBook copyBook)
        {
            return new CopyBookDetailsDTO
            {
                BookId = copyBook.BookId,
                EditionNum = copyBook.EditionNum,
                LibraryId = copyBook.LibraryId,
                PurchaseDate = copyBook.PurchaseDate,
                Remarks = copyBook.Remarks,
                Ubication = copyBook.Ubication,
                UserCreatedId = copyBook.UserCreatedId,
                Id = copyBook.Id,
                Status = copyBook.Status

            };
        }

        public static CopyBook ToCopyBook(this CopyBookCreateDTO copyBook)
        {
            return new CopyBook
            {
                BookId = copyBook.BookId,
                EditionNum = copyBook.EditionNum,
                LibraryId = copyBook.LibraryId,
                PurchaseDate = copyBook.PurchaseDate,
                Remarks = copyBook.Remarks,
                Ubication = copyBook.Ubication,
            };
        }
    }
}
