﻿namespace LibraryGest.Models.Extensions
{
    public static class ArchiveExtensions
    {
        public static ArchiveDetailsDTO ToDetailsDTO(this Archive archive)
        {
            return new ArchiveDetailsDTO
            {
                Title = archive.Title,
                PublicationDate = archive.PublicationDate,
                Summary = archive.Summary,
                UserCreatedId = archive.UserCreatedId,
                Id = archive.Id,
                File = archive.File != null ? Convert.ToBase64String(archive.File) : null,
                FileMimeType = archive.FileMimeType,
                AuthorIds = archive.AuthorArchives?
                    .Select(ab => new AuthorDetailsDTO
                    {
                        Id = ab.Author.Id,
                        NameSurname = ab.Author.NameSurname
                    }).ToList()

            };
        }

        public static Archive ToArchive(this ArchiveCreateDTO archive)
        {
            return new Archive
            {
                Summary = archive.Summary,
                PublicationDate = archive.PublicationDate,
                Title = archive.Title,
                File = string.IsNullOrWhiteSpace(archive.File) ? null : Convert.FromBase64String(archive.File),
                FileMimeType = archive.FileMimeType,
            };
        }
    }
}
