﻿using Humanizer;
using Microsoft.DotNet.Scaffolding.Shared;

namespace LibraryGest.Models.Extensions
{
    public static class LibraryExtensions
    {
        public static LibraryDetailsDTO ToDetailsDTO(this Library library)
        {
            return new LibraryDetailsDTO
            {
                Address = library.Address,
                CIF = library.CIF,
                Email = library.Email,
                Name = library.Name,
                PhoneNumber = library.PhoneNumber,
                Description = library.Description,
                UserCreatedId = library.UserCreatedId,
                Id = library.Id,
                Photo = library.Photo != null ? Convert.ToBase64String(library.Photo) : null,
                PhotoMimeType = library.PhotoMimeType,
                FloorNumbers = library.FloorNumbers

            };
        }

        public static Library ToLibrary(this LibraryCreateDTO library)
        {
            return new Library
            {
                Description = library.Description,
                Address = library.Address,
                PhoneNumber = library.PhoneNumber,
                Name = library.Name,
                CIF = library.CIF,
                Email = library.Email,
                Photo = string.IsNullOrWhiteSpace(library.Photo) ? null : Convert.FromBase64String(library.Photo),
                PhotoMimeType = library.PhotoMimeType,
                FloorNumbers = library.FloorNumbers,
            };
        }

    }
}
