﻿namespace LibraryGest.Models
{
    public class Archive
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Summary { get; set; }
        public DateOnly PublicationDate { get; set; }
        public string FileMimeType { get; set; }
        public byte[] File { get; set; }

        public int UserCreatedId { get; set; }
        public User UserCreated { get; set; }

        public ICollection<AuthorArchive> AuthorArchives { get; set; } = new List<AuthorArchive>();

    }

    public class ArchiveCreateDTO
    {
        public string Title { get; set; }
        public string Summary { get; set; }
        public List<int> AuthorIds { get; set; }
        public DateOnly PublicationDate { get; set; }
        public string File { get; set; }
        public string FileMimeType { get; set; }
    }

    public class ArchiveDetailsDTO
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Summary { get; set; }
        public DateOnly PublicationDate { get; set; }
        public string FileMimeType { get; set; }
        public string File { get; set; }
        public int UserCreatedId { get; set; }
        public List<AuthorDetailsDTO> AuthorIds { get; set; }
    }

    public class ArchiveSearchParams
    {
        public int PageNum { get; set; } = 0;
        public int PageSize { get; set; } = 10;
        public DateOnly? PublicationDate { get; set; }
        public string? Title { get; set; }
        public string? Author { get; set; }
        public string? OrderBy { get; set; }
        public string? OrderField { get; set; }
    }
}
