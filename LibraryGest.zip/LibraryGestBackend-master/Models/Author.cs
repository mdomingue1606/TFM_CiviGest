﻿namespace LibraryGest.Models
{
    public class Author
    {
        public int Id { get; set; }
        public string NameSurname { get; set; }
        public ICollection<AuthorBook> AuthorBooks { get; set; } = new List<AuthorBook>();
        public ICollection<AuthorArchive> AuthorArchives { get; set; } = new List<AuthorArchive>();
    }

    public class AuthorDetailsDTO
    {
        public int Id { get; set; }
        public string NameSurname { get; set; }
    }
    public class AuthorSearchParams
    {
        public int PageNum { get; set; } = 0;
        public int PageSize { get; set; } = 10;
        public string? Name { get; set; }
        public string? OrderBy { get; set; }
        public string? OrderField { get; set; }
    }
}
