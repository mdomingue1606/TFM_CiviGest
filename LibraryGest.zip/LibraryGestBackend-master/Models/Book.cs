﻿namespace LibraryGest.Models
{
    public class Book
    {
        public int Id { get; set; }
        public string ISBN { get; set; }
        public string Title { get; set; }
        public string Summary { get; set; }
        public string PagNum { get; set; }
        public DateOnly PublicationDate { get; set; }
        public string Publisher { get; set; }
        public byte[] Photo { get; set; }
        public string PhotoMimeType { get; set; }

        public int UserCreatedId { get; set; }
        public User UserCreated { get; set; }

        public ICollection<AuthorBook> AuthorBooks { get; set; } = new List<AuthorBook>();
    }

    public class BookCreateDTO
    {
        public string ISBN { get; set; }
        public string Title { get; set; }
        public string Summary { get; set; }
        public List<int> AuthorIds { get; set; }
        public string PagNum { get; set; }
        public DateOnly PublicationDate { get; set; }
        public string Photo { get; set; }
        public string PhotoMimeType { get; set; }
        public string Publisher { get; set; }
    }

    public class BookDetailsDTO
    {
        public string ISBN { get; set; }
        public string Title { get; set; }
        public string Summary { get; set; }
        public List<AuthorDetailsDTO> AuthorIds { get; set; }
        public string PagNum { get; set; }
        public DateOnly PublicationDate { get; set; }
        public int UserCreatedId { get; set; }
        public int Id { get; set; }
        public string Photo { get; set; }
        public string PhotoMimeType { get; set; }
        public string Publisher { get; set; }
    }

    public class BookSearchParams
    {
        public int PageNum { get; set; } = 0;
        public int PageSize { get; set; } = 10;
        public string? Title { get; set; }
        public string? Isbn { get; set; }
        public string? Author { get; set; }
        public string? Publisher { get; set; }
        public string? OrderBy { get; set; }
        public string? OrderField { get; set; }
    }


}
