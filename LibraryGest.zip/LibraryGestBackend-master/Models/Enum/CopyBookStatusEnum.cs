﻿namespace LibraryGest.Models.Enum
{
    public enum CopyBookStatusEnum
    {
        Disponible,
        Reservado,
        Dañado,
        Perdido
    }
}
