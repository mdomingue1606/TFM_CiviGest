﻿namespace LibraryGest.Models.Enum
{
    public enum RoleEnum
    {
        Admin,
        Gestor,
        Cliente
    }
}
