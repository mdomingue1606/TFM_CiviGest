﻿namespace LibraryGest.Models
{
    public class AuthorArchive
    {
        public int AuthorId { get; set; }
        public Author Author { get; set; }
        public int ArchiveId { get; set; }
        public Archive Archive { get; set; }
    }
}
