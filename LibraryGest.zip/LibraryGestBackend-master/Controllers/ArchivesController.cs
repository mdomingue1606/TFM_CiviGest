﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using LibraryGest.Context;
using LibraryGest.Models;
using LibraryGest.Services;
using Microsoft.AspNetCore.Authorization;

namespace LibraryGest.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ArchivesController : ControllerBase
    {
        private readonly IArchiveService archiveService;
        private readonly ICurrentInfoAuthService currentInfoAuthService;
        private readonly IAuthorService authorService;

        public ArchivesController(IArchiveService archiveService, ICurrentInfoAuthService currentInfoAuthService, IAuthorService authorService)
        {
            this.archiveService = archiveService;
            this.currentInfoAuthService = currentInfoAuthService;
            this.authorService = authorService;
        }

        // GET: api/Archives
        [HttpGet]
        [Authorize]
        public async Task<ActionResult<PageResult<ArchiveDetailsDTO>>> GetBook(int npag = 0, int nelem = 10, string? titulo = null, DateOnly? fecha = null, string? autor = null, string? orden = null, string? campoOrden = null)
        {
            ArchiveSearchParams pSearchParams = new ArchiveSearchParams
            {
                PageSize = nelem,
                Title = titulo,
                Author = autor,
                PublicationDate= fecha,
                PageNum = npag,
                OrderBy = orden,
                OrderField = campoOrden,
            };
            return await archiveService.ObtenerArchivosAsync(pSearchParams);
        }

        // GET: api/Archives/5
        [HttpGet("{id}")]
        [Authorize]
        public async Task<ActionResult<ArchiveDetailsDTO>> GetArchive(int id)
        {
            var archive = await archiveService.ObtenerArchivoDetallesIdAsync(id);

            if (archive == null)
            {
                return NotFound();
            }

            return archive;
        }

        // PUT: api/Archives/5
        [HttpPut("{id}")]
        [Authorize(Roles = "Admin,Gestor")]
        public async Task<IActionResult> PutArchive(int id, [FromBody] ArchiveDetailsDTO archive)
        {
            try
            {
                CurrentUserInfoAuth infoUser = currentInfoAuthService.ObtenerInfoAuth(Request);
                var res = await archiveService.ActualizarArchivoAsync(id, archive, infoUser);
                if (!res)
                {
                    return NotFound();
                }
                return NoContent();
            }
            catch (UnauthorizedAccessException ex)
            {
                return Unauthorized(ex.Message);
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!archiveService.ExisteArchivo(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }
        }

        // POST: api/Archives
        [HttpPost]
        [Authorize(Roles = "Admin,Gestor")]
        public async Task<ActionResult<Archive>> PostArchive(ArchiveCreateDTO archive)
        {
            try
            {
                CurrentUserInfoAuth infoUser = currentInfoAuthService.ObtenerInfoAuth(Request);
                if (infoUser.Id == null)
                {
                    return BadRequest("El token no está bien formado");
                }
                int archivoId = await archiveService.CrearArchivoAsync(archive, infoUser.Id.Value);
                //Put relations between authors.
                await authorService.AsignarAutoresAArchivosAsync(archivoId, archive.AuthorIds);

                return Created("", new { message = "Archivo creado", archive.Title });
            }
            catch (ArgumentException ex)
            {
                return BadRequest(new { error = ex.Message });
            }
        }

        // DELETE: api/Archives/5
        [HttpDelete("{id}")]
        [Authorize(Roles = "Admin,Gestor")]
        public async Task<IActionResult> DeleteArchive(int id)
        {
            try
            {
                CurrentUserInfoAuth infoUser = currentInfoAuthService.ObtenerInfoAuth(Request);
                var res = await archiveService.EliminarArchivoAsync(id, infoUser);
                if (!res)
                {
                    return NotFound();
                }
                await authorService.EliminarRelacionArchivoIdAsync(id);

                return NoContent();
            }
            catch (UnauthorizedAccessException ex)
            {
                return Unauthorized(ex.Message);
            }
        }
    }
}
