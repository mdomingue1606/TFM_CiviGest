﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using LibraryGest.Context;
using LibraryGest.Models;
using LibraryGest.Services;
using Microsoft.AspNetCore.Authorization;

namespace LibraryGest.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthorsController : ControllerBase
    {
        private readonly IAuthorService authorService;

        public AuthorsController(IAuthorService authorService )
        {
            this.authorService = authorService;
        }

        // GET: api/Authors
        [HttpGet]
        public async Task<ActionResult<PageResult<AuthorDetailsDTO>>> GetAuthor(int npag = 0, int nelem = 10, string? nombre = null)
        {
            AuthorSearchParams pSearchParams = new AuthorSearchParams
            {
                PageSize = nelem,
                Name = nombre,
                PageNum = npag,
            };
            return await authorService.ObtenerAutoresAsync(pSearchParams);
        }

        // GET: api/Authors/5
        [HttpGet("{id}")]
        public async Task<ActionResult<AuthorDetailsDTO>> GetAuthor(int id)
        {
            var author = await authorService.ObtenerAutorDetallesIdAsync(id);

            if (author == null)
            {
                return NotFound();
            }

            return author;
        }

        // PUT: api/Authors/5
        [HttpPut("{id}")]
        [Authorize(Roles="Admin,Gestor")]
        public async Task<IActionResult> PutAuthor(int id, [FromBody] AuthorDetailsDTO author)
        {
            try
            {
                var res = await authorService.ActualizarAutorAsync(id, author);
                if (!res)
                {
                    return NotFound();
                }
                return NoContent();
            }
            catch (UnauthorizedAccessException ex)
            {
                return Unauthorized(ex.Message);
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!authorService.ExisteAutor(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }
        }

        // POST: api/Authors
        [HttpPost]
        [Authorize(Roles = "Admin,Gestor")]
        public async Task<ActionResult<Author>> PostAuthor(string authorName)
        {

            try
            {
                await authorService.CrearAutorAsync(authorName);
                AuthorDetailsDTO author = await authorService.ObtenerAutorDetallesNameAsync(authorName);

                return Created("", new { message = "Autor creado", author });
            }
            catch (ArgumentException ex)
            {
                return BadRequest(new { error = ex.Message });
            }
        }

        // DELETE: api/Authors/5
        [HttpDelete("{id}")]
        [Authorize(Roles = "Admin,Gestor")]
        public async Task<IActionResult> DeleteAuthor(int id)
        {
            try
            {
                var res = await authorService.EliminarAutorAsync(id);
                if (!res)
                {
                    return NotFound();
                }

                return NoContent();
            }
            catch (UnauthorizedAccessException ex)
            {
                return Unauthorized(ex.Message);
            }
        }

    }
}
