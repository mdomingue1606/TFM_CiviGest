﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using LibraryGest.Context;
using LibraryGest.Models;
using LibraryGest.Services;
using Microsoft.AspNetCore.Authorization;

namespace LibraryGest.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BooksController : ControllerBase
    {
        private readonly IBookService bookService;
        private readonly ICurrentInfoAuthService currentInfoAuthService;
        private readonly IAuthorService authorService;

        public BooksController(IBookService bookService, ICurrentInfoAuthService currentInfoAuthService, IAuthorService authorService)
        {
            this.bookService = bookService;
            this.currentInfoAuthService = currentInfoAuthService;
            this.authorService = authorService;
        }

        // GET: api/Books
        [HttpGet]
        public async Task<ActionResult<PageResult<BookDetailsDTO>>> GetBook(int npag = 0, int nelem = 10, string? titulo = null, string? isbn = null, string? autor = null, string? editorial = null, string? orden = null, string? campoOrden = null)
        {
            BookSearchParams pSearchParams = new BookSearchParams
            {
                PageSize = nelem,
                Title = titulo,
                Author = autor,
                Isbn = isbn,
                Publisher = editorial,
                PageNum = npag,
                OrderBy = orden,
                OrderField = campoOrden,
            };
            return await bookService.ObtenerLibrosAsync(pSearchParams);
        }

        // GET: api/Books/5
        [HttpGet("{id}")]
        public async Task<ActionResult<BookDetailsDTO>> GetBook(int id)
        {
            var book = await bookService.ObtenerLibroDetallesIdAsync(id);

            if (book == null)
            {
                return NotFound();
            }

            return book;
        }

        // PUT: api/Books/5
        [HttpPut("{id}")]
        [Authorize(Roles = "Admin,Gestor")]
        public async Task<IActionResult> PutBook(int id, [FromBody] BookDetailsDTO book)
        {
            try
            {
                CurrentUserInfoAuth infoUser = currentInfoAuthService.ObtenerInfoAuth(Request);
                var res = await bookService.ActualizarLibroAsync(id, book, infoUser);
                if (!res)
                {
                    return NotFound();
                }
                return NoContent();
            }
            catch (UnauthorizedAccessException ex)
            {
                return Unauthorized(ex.Message);
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!bookService.ExisteLibro(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }
        }

        // POST: api/Books
        [HttpPost]
        [Authorize(Roles = "Admin,Gestor")]
        public async Task<ActionResult<Book>> PostBook(BookCreateDTO book)
        {
            try
            {
                CurrentUserInfoAuth infoUser = currentInfoAuthService.ObtenerInfoAuth(Request);
                if (infoUser.Id == null)
                {
                    return BadRequest("El token no está bien formado");
                }
                int bookId = await bookService.CrearLibroAsync(book, infoUser.Id.Value);
                //Put relations between authors.
                await authorService.AsignarAutoresALibrosAsync(bookId, book.AuthorIds);

                return Created("", new { message = "Libro creado", book.Title });
            }
            catch (ArgumentException ex)
            {
                return BadRequest(new { error = ex.Message });
            }
        }

        // DELETE: api/Books/5
        [HttpDelete("{id}")]
        [Authorize(Roles = "Admin,Gestor")]
        public async Task<IActionResult> DeleteBook(int id)
        {
            try
            {
                CurrentUserInfoAuth infoUser = currentInfoAuthService.ObtenerInfoAuth(Request);
                var res = await bookService.EliminarLibroAsync(id, infoUser);
                if (!res)
                {
                    return NotFound();
                }
                await authorService.EliminarRelacionLibroIdAsync(id);

                return NoContent();
            }
            catch (UnauthorizedAccessException ex)
            {
                return Unauthorized(ex.Message);
            }
        }

        // GET: api/Books/CopyBooks
        [HttpGet("CopyBooks")] // --> Revisar
        public async Task<ActionResult<PageResult<CopyBookDetailsDTO>>> GetCopyBook(int npag = 0, int nelem = 10, string? libro = null, string? biblio = null, string? estado = null,
                                                                                    int? libroId = null, int? biblioId = null, string? orden = null, string? campoOrden = null)
        {
            CopyBookSearchParams pSearchParams = new CopyBookSearchParams
            {
                PageSize = nelem,
                Book = libro,
                Library = biblio,
                BookId = libroId,
                LibraryId = biblioId,
                Status = estado,
                PageNum = npag,
                OrderBy = orden,
                OrderField = campoOrden,
            };
            return await bookService.ObtenerEjemplaresAsync(pSearchParams);
        }

        // GET: api/Books/CopyBooks/5
        [HttpGet("CopyBooks/{id}")]
        public async Task<ActionResult<CopyBookDetailsDTO>> GetCopyBook(int id)
        {
            var copybook = await bookService.ObtenerEjemplarDetallesIdAsync(id);

            if (copybook == null)
            {
                return NotFound();
            }

            return copybook;
        }

        // PUT: api/Books/CopyBooks/5
        [HttpPut("CopyBooks/{id}")]
        [Authorize] // <--- REVISAR
        public async Task<IActionResult> PutCopyBook(int id, [FromBody] CopyBookDetailsDTO copyBook)
        {
            try
            {
                CurrentUserInfoAuth infoUser = currentInfoAuthService.ObtenerInfoAuth(Request);
                var res = await bookService.ActualizarEjemplarAsync(id, copyBook, infoUser);
                if (!res)
                {
                    return NotFound();
                }
                return NoContent();
            }
            catch (UnauthorizedAccessException ex)
            {
                return Unauthorized(ex.Message);
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!bookService.ExisteLibro(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }
        }

        // POST: api/Books/CopyBooks
        [HttpPost("CopyBooks")]
        [Authorize(Roles = "Admin,Gestor")]
        public async Task<ActionResult<CopyBook>> PostCopyBook(CopyBookCreateDTO copyBook)
        {
            try
            {
                CurrentUserInfoAuth infoUser = currentInfoAuthService.ObtenerInfoAuth(Request);
                if (infoUser.Id == null)
                {
                    return BadRequest("El token no está bien formado");
                }
                await bookService.CrearEjemplarAsync(copyBook, infoUser.Id.Value);

                return Created("", new { message = "Ejemplar creado", copyBook.BookId });
            }
            catch (ArgumentException ex)
            {
                return BadRequest(new { error = ex.Message });
            }
        }

        // DELETE: api/Books/CopyBooks/5
        [HttpDelete("CopyBooks/{id}")]
        [Authorize(Roles = "Admin,Gestor")]
        public async Task<IActionResult> DeleteCopyBook(int id)
        {
            try
            {
                CurrentUserInfoAuth infoUser = currentInfoAuthService.ObtenerInfoAuth(Request);
                var res = await bookService.EliminarEjemplarAsync(id, infoUser);
                if (!res)
                {
                    return NotFound();
                }

                return NoContent();
            }
            catch (UnauthorizedAccessException ex)
            {
                return Unauthorized(ex.Message);
            }
        }

    }
}
