﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using LibraryGest.Context;
using LibraryGest.Models;
using LibraryGest.Services;
using Microsoft.DotNet.Scaffolding.Shared;
using Microsoft.AspNetCore.Authorization;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace LibraryGest.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LibrariesController : ControllerBase
    {
        private readonly ILibraryService libraryService;
        private readonly ICurrentInfoAuthService currentInfoAuthService;

        public LibrariesController(ILibraryService libraryService, ICurrentInfoAuthService currentInfoAuthService)
        {
            this.libraryService = libraryService;
            this.currentInfoAuthService = currentInfoAuthService;
        }

        // GET: api/Libraries
        [HttpGet]
        public async Task<ActionResult<PageResult<LibraryDetailsDTO>>> GetLibrary(int npag = 0, int nelem = 10, string? nombre = null, string? orden = null, string? campoOrden = null)
        {
            LibrarySearchParams pSearchParams = new LibrarySearchParams
            {
                PageSize = nelem,
                Name = nombre,
                PageNum = npag,
                OrderBy = orden,
                OrderField = campoOrden,
            };
            return await libraryService.ObtenerBibliotecasAsync(pSearchParams);
        }

        // GET: api/Libraries/5
        [HttpGet("{id}")]
        public async Task<ActionResult<LibraryDetailsDTO>> GetLibrary(int id)
        {
            var library = await libraryService.ObtenerBibliotecaDetallesIdAsync(id);

            if (library == null)
            {
                return NotFound();
            }

            return library;
        }

        // PUT: api/Libraries/5
        [HttpPut("{id}")]
        [Authorize(Roles="Admin,Gestor")]
        public async Task<IActionResult> PutLibrary(int id, [FromBody] LibraryDetailsDTO library)
        {
            try
            {
                CurrentUserInfoAuth infoUser = currentInfoAuthService.ObtenerInfoAuth(Request);
                var res = await libraryService.ActualizarBibliotecaAsync(id, library, infoUser);
                if (!res)
                {
                    return NotFound();
                }
                return NoContent();
            }
            catch (UnauthorizedAccessException ex)
            {
                return Unauthorized(ex.Message);
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!libraryService.ExisteBiblioteca(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }
        }

        // POST: api/Libraries
        [HttpPost]
        [Authorize(Roles ="Admin,Gestor")]
        public async Task<ActionResult<Library>> PostLibrary(LibraryCreateDTO library)
        {
            try
            {
                CurrentUserInfoAuth infoUser = currentInfoAuthService.ObtenerInfoAuth(Request);
                if (infoUser.Id == null)
                {
                    return BadRequest("El token no está bien formado");
                }
                await libraryService.CrearBibliotecaAsync(library, infoUser.Id.Value);

                return Created("", new { message = "Biblioteca creada", library.Name });
            }
            catch (ArgumentException ex)
            {
                return BadRequest(new { error = ex.Message });
            }
        }

        // DELETE: api/Libraries/5
        [HttpDelete("{id}")]
        [Authorize(Roles = "Admin,Gestor")]
        public async Task<IActionResult> DeleteLibrary(int id)
        {
            try
            {
                CurrentUserInfoAuth infoUser = currentInfoAuthService.ObtenerInfoAuth(Request);
                var res = await libraryService.EliminarBibliotecaAsync(id, infoUser);
                if (!res)
                {
                    return NotFound();
                }

                return NoContent();
            }
            catch (UnauthorizedAccessException ex)
            {
                return Unauthorized(ex.Message);
            }
        }

    }
}
