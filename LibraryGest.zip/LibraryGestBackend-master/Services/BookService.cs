﻿using LibraryGest.Context;
using LibraryGest.Models.Enum;
using LibraryGest.Models;
using Microsoft.EntityFrameworkCore;
using LibraryGest.Models.Extensions;
using Microsoft.IdentityModel.Tokens;

namespace LibraryGest.Services
{
    public class BookService : IBookService
    {
        private readonly ApplicationDbContext context;

        public BookService(ApplicationDbContext context)
        {
            this.context = context;
        }

        public async Task<Book?> ObtenerLibroIdAsync(int id)
        {
            return await context.Book
                .Include(b => b.AuthorBooks)
                .ThenInclude(ab => ab.Author)
                .FirstOrDefaultAsync(b => b.Id == id);
        }

        public async Task<BookDetailsDTO?> ObtenerLibroDetallesIdAsync(int id)
        {
            Book book = await ObtenerLibroIdAsync(id);
            BookDetailsDTO? res = null;
            if (book != null)
            {
                res = book.ToDetailsDTO();
            }
            return res;
        }

        public async Task<int> CrearLibroAsync(BookCreateDTO data, int UserCreatedId)
        {
            //Check if ISBN is already in the system
            bool ISBNExists = await context.Book.AnyAsync(p => p.ISBN == data.ISBN);
            if (ISBNExists)
            {
                throw new ArgumentException("El ISBN ya está registrado.");
            }

            var book = data.ToBook();
            //Add the user who is creating the book
            book.UserCreatedId = UserCreatedId;

            context.Book.Add(book);
            await context.SaveChangesAsync();
            return book.Id;
        }

        public async Task<bool> EliminarLibroAsync(int id, CurrentUserInfoAuth infoUser)
        {

            var book = await ObtenerLibroIdAsync(id);
            if (book != null)
            {
                //If it is a gestor he only can remove his own providers.
                if (infoUser.Role == RoleEnum.Gestor.ToString() && book.UserCreatedId != infoUser.Id)
                {
                    throw new UnauthorizedAccessException("No tienes permisos para ello");
                }

                context.Remove(book);
                await context.SaveChangesAsync();
                return true;

            }
            return false;

        }

        public async Task<PageResult<BookDetailsDTO>> ObtenerLibrosAsync(BookSearchParams pSearchParams)
        {
            var query = context.Book
                .Include(b => b.AuthorBooks)
                .ThenInclude(ab => ab.Author)
                .AsQueryable();

            // Filter for the title
            if (!string.IsNullOrEmpty(pSearchParams.Title))
            {
                query = query.Where(b => b.Title.Contains(pSearchParams.Title));
            }

            //Filter for the isbn
            if (!string.IsNullOrEmpty(pSearchParams.Isbn))
            {
                query = query.Where(b => b.ISBN.Contains(pSearchParams.Isbn));
            }

            //Filter for the author
            if (!string.IsNullOrEmpty(pSearchParams.Author))
            {
                query = query.Where(b => b.AuthorBooks.Any(ab => ab.Author.NameSurname.Contains(pSearchParams.Author)));
            }

            //Filter for the publisher
            if (!string.IsNullOrEmpty(pSearchParams.Publisher))
            {
                query = query.Where(b => b.Publisher.Contains(pSearchParams.Publisher));
            }

            // Order by title
            if (pSearchParams.OrderField?.ToLower() == "titulo")
            {
                query = pSearchParams.OrderBy?.ToLower() == "desc"
                    ? query.OrderByDescending(p => p.Title)
                    : query.OrderBy(p => p.Title);
            }

            //Get totalElements
            var totalItems = await query.CountAsync();

            //Get totalPages
            var totalPages = (int)Math.Ceiling(totalItems / (double)pSearchParams.PageSize);

            // Pages.
            query = query.Skip(pSearchParams.PageNum * pSearchParams.PageSize)
                         .Take(pSearchParams.PageSize);

            var list = await query.ToListAsync();

            // Convert to DTO
            List<BookDetailsDTO> books = list.Select(p => p.ToDetailsDTO()).ToList();
            return new PageResult<BookDetailsDTO>
            {
                Items = books,
                TotalItems = totalItems,
                TotalPages = totalPages,
                CurrentPage = pSearchParams.PageNum,
                PageSize = pSearchParams.PageSize
            };
        }

        public async Task<bool> ActualizarLibroAsync(int id, BookDetailsDTO data, CurrentUserInfoAuth infoUser)
        {
            Book book = await ObtenerLibroIdAsync(id);
            if (book != null)
            {
                //If it is a gestor he only can update his own books.
                if (infoUser.Role == RoleEnum.Gestor.ToString() && book.UserCreatedId != infoUser.Id)
                {
                    throw new UnauthorizedAccessException("No tienes permisos para ello");
                }
                //Update values

                book.Summary = (data.Summary.IsNullOrEmpty()) ? book.Summary : data.Summary;
                book.Title = (data.Title.IsNullOrEmpty()) ? book.Title : data.Title;
                book.PagNum = (data.PagNum.IsNullOrEmpty()) ? book.PagNum : data.PagNum;
                book.Publisher = (data.Publisher.IsNullOrEmpty()) ? book.Publisher : data.Publisher;

                //Update photo
                if (!string.IsNullOrEmpty(data.Photo) && !string.IsNullOrEmpty(data.PhotoMimeType))
                {
                    book.PhotoMimeType = data.PhotoMimeType;
                    book.Photo = Convert.FromBase64String(data.Photo);
                }

                context.Entry(book).State = EntityState.Modified;
                await context.SaveChangesAsync();
                return true;
            }
            return false;

        }

        public bool ExisteLibro(int id)
        {
            return context.Book.Any(e => e.Id == id);
        }

        public async Task<CopyBook?> ObtenerEjemplarIdAsync(int id)
        {
            return await context.CopyBook.FindAsync(id);
        }

        public async Task<CopyBookDetailsDTO?> ObtenerEjemplarDetallesIdAsync(int id)
        {
            CopyBook copybook = await ObtenerEjemplarIdAsync(id);
            CopyBookDetailsDTO? res = null;
            if (copybook != null)
            {
                res = copybook.ToDetailsDTO();
            }
            return res;
        }

        public async Task CrearEjemplarAsync(CopyBookCreateDTO data, int UserCreatedId)
        {
            var copyBook = data.ToCopyBook();
            //Add the user who is creating the book
            copyBook.UserCreatedId = UserCreatedId;
            //Add the status
            copyBook.Status = CopyBookStatusEnum.Disponible.ToString();

            context.CopyBook.Add(copyBook);
            await context.SaveChangesAsync();
        }

        public async Task<bool> EliminarEjemplarAsync(int id, CurrentUserInfoAuth infoUser)
        {

            var copyBook = await ObtenerEjemplarIdAsync(id);
            if (copyBook != null)
            {
                //If it is a gestor he only can remove his own copybooks.
                if (infoUser.Role == RoleEnum.Gestor.ToString() && copyBook.UserCreatedId != infoUser.Id)
                {
                    throw new UnauthorizedAccessException("No tienes permisos para ello");
                }

                context.Remove(copyBook);
                await context.SaveChangesAsync();
                return true;

            }
            return false;

        }

        public async Task<PageResult<CopyBookDetailsDTO>> ObtenerEjemplaresAsync(CopyBookSearchParams pSearchParams)
        {
            var query = context.CopyBook
                .Include(b => b.Book)
                .Include(b => b.Library)
                .AsQueryable();

            // Filter for the book title
            if (!string.IsNullOrEmpty(pSearchParams.Book))
            {
                query = query.Where(p => p.Book.Title.Contains(pSearchParams.Book));
            }

            // Filter for the bookId
            if(pSearchParams.BookId.HasValue)
            {
                query = query.Where(p => p.BookId.Equals(pSearchParams.BookId));
            }

            // Filter for the libraryId
            if (pSearchParams.LibraryId.HasValue)
            {
                query = query.Where(p => p.LibraryId.Equals(pSearchParams.LibraryId));
            }

            //Filter for the library name
            if (!string.IsNullOrEmpty(pSearchParams.Library))
            {
                query = query.Where(p => p.Library.Name.Equals(pSearchParams.Library));
            }

            //Filter for the status
            if (!string.IsNullOrEmpty(pSearchParams.Status) && EsValidoEstado(pSearchParams.Status))
            {
                query = query.Where(u => u.Status.Contains(pSearchParams.Status));
            }

            // Order by status
            if (pSearchParams.OrderField?.ToLower() == "estado")
            {
                query = pSearchParams.OrderBy?.ToLower() == "desc"
                    ? query.OrderByDescending(p => p.Status)
                    : query.OrderBy(p => p.Status);
            }

            // Order by library name
            if (pSearchParams.OrderField?.ToLower() == "biblioteca")
            {
                query = pSearchParams.OrderBy?.ToLower() == "desc"
                    ? query.OrderByDescending(p => p.Library.Name)
                    : query.OrderBy(p => p.Library.Name);
            }

            // Order by book title
            if (pSearchParams.OrderField?.ToLower() == "titulo")
            {
                query = pSearchParams.OrderBy?.ToLower() == "desc"
                    ? query.OrderByDescending(p => p.Book.Title)
                    : query.OrderBy(p => p.Book.Title);
            }

            //Get totalElements
            var totalItems = await query.CountAsync();

            //Get totalPages
            var totalPages = (int)Math.Ceiling(totalItems / (double)pSearchParams.PageSize);

            // Pages.
            query = query.Skip(pSearchParams.PageNum * pSearchParams.PageSize)
                         .Take(pSearchParams.PageSize);

            var list = await query.ToListAsync();

            // Convert to DTO
            List<CopyBookDetailsDTO> copyBooks = list.Select(p => p.ToDetailsDTO()).ToList();
            return new PageResult<CopyBookDetailsDTO>
            {
                Items = copyBooks,
                TotalItems = totalItems,
                TotalPages = totalPages,
                CurrentPage = pSearchParams.PageNum,
                PageSize = pSearchParams.PageSize
            };
        }

        public async Task<bool> ActualizarEjemplarAsync(int id, CopyBookDetailsDTO data, CurrentUserInfoAuth infoUser)
        {
            CopyBook copyBook = await ObtenerEjemplarIdAsync(id);
            if (copyBook != null)
            {
                
                //If it is a client he only can update the status
                if (EsValidoEstado(data.Status))
                {
                    copyBook.Status = data.Status;
                }
                if(infoUser.Role != RoleEnum.Cliente.ToString())
                {
                    //If it is a gestor he only can update his own books.
                    if (infoUser.Role == RoleEnum.Admin.ToString() || ( infoUser.Role == RoleEnum.Gestor.ToString() && copyBook.UserCreatedId == infoUser.Id))
                    {
                        //Update values
                        copyBook.Remarks = (data.Remarks.IsNullOrEmpty()) ? copyBook.Remarks : data.Remarks;
                        copyBook.Ubication = (data.Ubication.IsNullOrEmpty()) ? copyBook.Ubication : data.Ubication;
                    }
                }

                context.Entry(copyBook).State = EntityState.Modified;
                await context.SaveChangesAsync();
                return true;
            }
            return false;

        }

        public bool ExisteEjemplar(int id)
        {
            return context.CopyBook.Any(e => e.Id == id);
        }

        private bool EsValidoEstado(string status)
        {
            bool isvalid = false;
            if (!status.IsNullOrEmpty())
            {
                isvalid = status.Equals(CopyBookStatusEnum.Dañado.ToString()) || status.Equals(CopyBookStatusEnum.Disponible.ToString()) ||
                           status.Equals(CopyBookStatusEnum.Perdido.ToString()) || status.Equals(CopyBookStatusEnum.Reservado.ToString());
            }
            return isvalid;
        }
    }
}
