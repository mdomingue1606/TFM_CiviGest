﻿using LibraryGest.Models;

namespace LibraryGest.Services
{
    public interface IAuthorService
    {
        Task<AuthorDetailsDTO?> ObtenerAutorDetallesIdAsync(int id);
        Task<PageResult<AuthorDetailsDTO>> ObtenerAutoresAsync(AuthorSearchParams pSearchParams);
        Task CrearAutorAsync(string name);
        Task<bool> ActualizarAutorAsync(int id, AuthorDetailsDTO data);
        Task<bool> EliminarAutorAsync(int id);
        bool ExisteAutor(int id);
        Task AsignarAutoresALibrosAsync(int bookId, List<int> authorsIds);
        Task EliminarRelacionLibroIdAsync(int bookId);
        Task EliminarRelacionAutorIdLibroAsync(int authorId);
        Task AsignarAutoresAArchivosAsync(int archiveId, List<int> authorsIds);
        Task EliminarRelacionArchivoIdAsync(int archiveId);
        Task EliminarRelacionAutorIdArchivoAsync(int authorId);
        Task<Author?> ObtenerAutorByNameAsync(string name);
        Task<AuthorDetailsDTO?> ObtenerAutorDetallesNameAsync(string name);

    }
}
