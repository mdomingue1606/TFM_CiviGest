﻿using LibraryGest.Context;
using LibraryGest.Models.Enum;
using LibraryGest.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;

namespace LibraryGest.Services
{
    public class AuthorService : IAuthorService
    {
        private readonly ApplicationDbContext context;

        public AuthorService(ApplicationDbContext context)
        {
            this.context = context;
        }

        public async Task<Author?> ObtenerAutorIdAsync(int id)
        {
            return await context.Author.FindAsync(id);
        }

        public async Task<Author?> ObtenerAutorByNameAsync(string name)
        {
            return await context.Author.FirstOrDefaultAsync(u => u.NameSurname == name);
        }

        public async Task<AuthorDetailsDTO?> ObtenerAutorDetallesIdAsync(int id)
        {
            Author author = await ObtenerAutorIdAsync(id);
            AuthorDetailsDTO? res = null;
            if (author != null)
            {
                res = new AuthorDetailsDTO
                {
                    Id = author.Id,
                    NameSurname = author.NameSurname
                };
            }
            return res;
        }

        public async Task<AuthorDetailsDTO?> ObtenerAutorDetallesNameAsync(string name)
        {
            Author author = await ObtenerAutorByNameAsync(name);
            AuthorDetailsDTO? res = null;
            if (author != null)
            {
                res = new AuthorDetailsDTO
                {
                    Id = author.Id,
                    NameSurname = author.NameSurname
                };
            }
            return res;
        }


        public async Task CrearAutorAsync(string data)
        {
            Author author = new Author
            {
                NameSurname = data
            };

            var a = context.Author.Add(author);
            await context.SaveChangesAsync();
        }

        public async Task<bool> EliminarAutorAsync(int id) //REVISAR
        {

            var author = await ObtenerAutorIdAsync(id);
            if (author != null)
            {
                context.Remove(author);

                var authorBooks = await context.AuthorBook
                                    .Where(ab => ab.AuthorId == id)
                                    .ToListAsync();

                context.AuthorBook.RemoveRange(authorBooks);

                var authorArchives = await context.AuthorArchive
                                    .Where(ab => ab.AuthorId == id)
                                    .ToListAsync();

                context.AuthorArchive.RemoveRange(authorArchives);

                await context.SaveChangesAsync();
                return true;

            }
            return false;

        }

        public async Task<PageResult<AuthorDetailsDTO>> ObtenerAutoresAsync(AuthorSearchParams pSearchParams) // REVISAR
        {
            var query = context.Author.AsQueryable();

            // Filter for the name
            if (!string.IsNullOrEmpty(pSearchParams.Name))
            {
                query = query.Where(p => p.NameSurname.Contains(pSearchParams.Name));
            }

            // Order by name
            if (pSearchParams.OrderField?.ToLower() == "nombre")
            {
                query = pSearchParams.OrderBy?.ToLower() == "desc"
                    ? query.OrderByDescending(p => p.NameSurname)
                    : query.OrderBy(p => p.NameSurname);
            }

            //Get totalElements
            var totalItems = await query.CountAsync();

            //Get totalPages
            var totalPages = (int)Math.Ceiling(totalItems / (double)pSearchParams.PageSize);

            // Pages.
            query = query.Skip(pSearchParams.PageNum * pSearchParams.PageSize)
                         .Take(pSearchParams.PageSize);

            var list = await query.ToListAsync();

            // Convert to DTO
            List<AuthorDetailsDTO> authors = list.Select(p => new AuthorDetailsDTO
            {
                Id = p.Id,
                NameSurname = p.NameSurname
            }).ToList();

            return new PageResult<AuthorDetailsDTO>
            {
                Items = authors,
                TotalItems = totalItems,
                TotalPages = totalPages,
                CurrentPage = pSearchParams.PageNum,
                PageSize = pSearchParams.PageSize
            };
        }

        public async Task<bool> ActualizarAutorAsync(int id, AuthorDetailsDTO data)
        {
            Author author = await ObtenerAutorIdAsync(id);
            if (author != null)
            {
                //Update values
                author.NameSurname = (data.NameSurname.IsNullOrEmpty()) ? author.NameSurname : data.NameSurname;

                context.Entry(author).State = EntityState.Modified;
                await context.SaveChangesAsync();
                return true;
            }
            return false;

        }

        public bool ExisteAutor(int id)
        {
            return context.Author.Any(e => e.Id == id);
        }

        public async Task AsignarAutoresALibrosAsync(int bookId, List<int> authorsIds)
        {
            //If there are, we delete the relations created before.
            var existing = context.AuthorBook.Where(ab => ab.BookId == bookId).ToList();
            context.AuthorBook.RemoveRange(existing);

            //We create new relations
            var newRelations = authorsIds.Select(id => new AuthorBook
            {
                BookId = bookId,
                AuthorId = id,
            });

            await context.AuthorBook.AddRangeAsync(newRelations);
            await context.SaveChangesAsync();

        }

        public async Task EliminarRelacionLibroIdAsync(int bookId)
        {
            var authorBooks = await context.AuthorBook
                                    .Where(ab => ab.BookId == bookId)
                                    .ToListAsync();

            context.AuthorBook.RemoveRange(authorBooks);
            await context.SaveChangesAsync();
        }

        public async Task EliminarRelacionAutorIdLibroAsync(int authorId)
        {
            var authorBooks = await context.AuthorBook
                                    .Where(ab => ab.AuthorId == authorId)
                                    .ToListAsync();

            context.AuthorBook.RemoveRange(authorBooks);
            await context.SaveChangesAsync();
        }

        public async Task AsignarAutoresAArchivosAsync(int archiveId, List<int> authorsIds)
        {
            //If there are, we delete the relations created before.
            var existing = context.AuthorArchive.Where(ab => ab.ArchiveId == archiveId).ToList();
            context.AuthorArchive.RemoveRange(existing);

            //We create new relations
            var newRelations = authorsIds.Select(id => new AuthorArchive
            {
                ArchiveId = archiveId,
                AuthorId = id,
            });

            await context.AuthorArchive.AddRangeAsync(newRelations);
            await context.SaveChangesAsync();

        }

        public async Task EliminarRelacionArchivoIdAsync(int archiveId)
        {
            var authorArchives = await context.AuthorArchive
                                    .Where(ab => ab.ArchiveId == archiveId)
                                    .ToListAsync();

            context.AuthorArchive.RemoveRange(authorArchives);
            await context.SaveChangesAsync();
        }

        public async Task EliminarRelacionAutorIdArchivoAsync(int authorId)
        {
            var authorArchives = await context.AuthorArchive
                                    .Where(ab => ab.AuthorId == authorId)
                                    .ToListAsync();

            context.AuthorArchive.RemoveRange(authorArchives);
            await context.SaveChangesAsync();
        }

    }
}
