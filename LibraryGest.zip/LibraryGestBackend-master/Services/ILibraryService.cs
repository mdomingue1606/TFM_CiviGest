﻿using LibraryGest.Models;
using Microsoft.DotNet.Scaffolding.Shared;
namespace LibraryGest.Services
{
    public interface ILibraryService
    {
        Task<LibraryDetailsDTO?> ObtenerBibliotecaDetallesIdAsync(int id);
        Task<PageResult<LibraryDetailsDTO>> ObtenerBibliotecasAsync(LibrarySearchParams pSearchParams);
        Task CrearBibliotecaAsync(LibraryCreateDTO data, int UserCreatedId);
        Task<bool> ActualizarBibliotecaAsync(int id, LibraryDetailsDTO data, CurrentUserInfoAuth infoUser);
        Task<bool> EliminarBibliotecaAsync(int id, CurrentUserInfoAuth infoUser);
        bool ExisteBiblioteca(int id);

    }
}
