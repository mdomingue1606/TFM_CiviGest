﻿using LibraryGest.Models;

namespace LibraryGest.Services
{
    public interface IBookService
    {
        Task<BookDetailsDTO?> ObtenerLibroDetallesIdAsync(int id);
        Task<PageResult<BookDetailsDTO>> ObtenerLibrosAsync(BookSearchParams pSearchParams);
        Task<int> CrearLibroAsync(BookCreateDTO data, int UserCreatedId);
        Task<bool> ActualizarLibroAsync(int id, BookDetailsDTO data, CurrentUserInfoAuth infoUser);
        Task<bool> EliminarLibroAsync(int id, CurrentUserInfoAuth infoUser);
        bool ExisteLibro(int id);

        //Part of the copybooks

        Task<CopyBookDetailsDTO?> ObtenerEjemplarDetallesIdAsync(int id);
        Task<PageResult<CopyBookDetailsDTO>> ObtenerEjemplaresAsync(CopyBookSearchParams pSearchParams);
        Task CrearEjemplarAsync(CopyBookCreateDTO data, int UserCreatedId);
        Task<bool> ActualizarEjemplarAsync(int id, CopyBookDetailsDTO data, CurrentUserInfoAuth infoUser);
        Task<bool> EliminarEjemplarAsync(int id, CurrentUserInfoAuth infoUser);
        bool ExisteEjemplar(int id);
    }
}
