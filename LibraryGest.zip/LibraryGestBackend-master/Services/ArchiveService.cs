﻿using LibraryGest.Context;
using LibraryGest.Models.Enum;
using LibraryGest.Models;
using Microsoft.EntityFrameworkCore;
using LibraryGest.Models.Extensions;
using Microsoft.IdentityModel.Tokens;

namespace LibraryGest.Services
{
    public class ArchiveService: IArchiveService
    {
        private readonly ApplicationDbContext context;

        public ArchiveService(ApplicationDbContext context)
        {
            this.context = context;
        }

        public async Task<Archive?> ObtenerArchivoIdAsync(int id)
        {
            return await context.Archive
                .Include(b => b.AuthorArchives)
                .ThenInclude(ab => ab.Author)
                .FirstOrDefaultAsync(b => b.Id == id);
        }

        public async Task<ArchiveDetailsDTO?> ObtenerArchivoDetallesIdAsync(int id)
        {
            Archive archive = await ObtenerArchivoIdAsync(id);
            ArchiveDetailsDTO? res = null;
            if (archive != null)
            {
                res = archive.ToDetailsDTO();
            }
            return res;
        }

        public async Task<int> CrearArchivoAsync(ArchiveCreateDTO data, int UserCreatedId)
        {
            var archive = data.ToArchive();
            //Add the user who is creating the book
            archive.UserCreatedId = UserCreatedId;

            context.Archive.Add(archive);
            await context.SaveChangesAsync();
            return archive.Id;
        }

        public async Task<bool> EliminarArchivoAsync(int id, CurrentUserInfoAuth infoUser)
        {

            var archive = await ObtenerArchivoIdAsync(id);
            if (archive != null)
            {
                //If it is a gestor he only can remove his own archives.
                if (infoUser.Role == RoleEnum.Gestor.ToString() && archive.UserCreatedId != infoUser.Id)
                {
                    throw new UnauthorizedAccessException("No tienes permisos para ello");
                }

                context.Remove(archive);
                await context.SaveChangesAsync();
                return true;

            }
            return false;

        }

        public async Task<PageResult<ArchiveDetailsDTO>> ObtenerArchivosAsync(ArchiveSearchParams pSearchParams)
        {
            var query = context.Archive
                .Include(b => b.AuthorArchives)
                .ThenInclude(ab => ab.Author)
                .AsQueryable();

            // Filter for the title
            if (!string.IsNullOrEmpty(pSearchParams.Title))
            {
                query = query.Where(b => b.Title.Contains(pSearchParams.Title));
            }

            //Filter for the publication date
            if (pSearchParams.PublicationDate.HasValue)
            {
                query = query.Where(b => b.PublicationDate == pSearchParams.PublicationDate);
            }

            //Filter for the author
            if (!string.IsNullOrEmpty(pSearchParams.Author))
            {
                query = query.Where(b => b.AuthorArchives.Any(ab => ab.Author.NameSurname.Contains(pSearchParams.Author)));
            }

            // Order by title
            if (pSearchParams.OrderField?.ToLower() == "titulo")
            {
                query = pSearchParams.OrderBy?.ToLower() == "desc"
                    ? query.OrderByDescending(p => p.Title)
                    : query.OrderBy(p => p.Title);
            }

            // Order by publicationDate
            if (pSearchParams.OrderField?.ToLower() == "fecha")
            {
                query = pSearchParams.OrderBy?.ToLower() == "desc"
                    ? query.OrderByDescending(p => p.PublicationDate)
                    : query.OrderBy(p => p.PublicationDate);
            }

            //Get totalElements
            var totalItems = await query.CountAsync();

            //Get totalPages
            var totalPages = (int)Math.Ceiling(totalItems / (double)pSearchParams.PageSize);

            // Pages.
            query = query.Skip(pSearchParams.PageNum * pSearchParams.PageSize)
                         .Take(pSearchParams.PageSize);

            var list = await query.ToListAsync();

            // Convert to DTO
            List<ArchiveDetailsDTO> archives = list.Select(p => p.ToDetailsDTO()).ToList();
            return new PageResult<ArchiveDetailsDTO>
            {
                Items = archives,
                TotalItems = totalItems,
                TotalPages = totalPages,
                CurrentPage = pSearchParams.PageNum,
                PageSize = pSearchParams.PageSize
            };
        }

        public async Task<bool> ActualizarArchivoAsync(int id, ArchiveDetailsDTO data, CurrentUserInfoAuth infoUser)
        {
            Archive archive = await ObtenerArchivoIdAsync(id);
            if (archive != null)
            {
                //If it is a gestor he only can update his own archives.
                if (infoUser.Role == RoleEnum.Gestor.ToString() && archive.UserCreatedId != infoUser.Id)
                {
                    throw new UnauthorizedAccessException("No tienes permisos para ello");
                }
                //Update values

                archive.Summary = (data.Summary.IsNullOrEmpty()) ? archive.Summary : data.Summary;
                archive.Title = (data.Title.IsNullOrEmpty()) ? archive.Title : data.Title;
                archive.PublicationDate = (data.PublicationDate.Equals(archive.PublicationDate)) ? archive.PublicationDate : data.PublicationDate;

                //Update file
                if (!string.IsNullOrEmpty(data.File) && !string.IsNullOrEmpty(data.FileMimeType))
                {
                    archive.FileMimeType = data.FileMimeType;
                    archive.File = Convert.FromBase64String(data.File);
                }

                context.Entry(archive).State = EntityState.Modified;
                await context.SaveChangesAsync();
                return true;
            }
            return false;

        }

        public bool ExisteArchivo(int id)
        {
            return context.Archive.Any(e => e.Id == id);
        }
    }
}
