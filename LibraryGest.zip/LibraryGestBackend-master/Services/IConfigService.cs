﻿using LibraryGest.Models;

namespace LibraryGest.Services
{
    public interface IConfigService
    {
        Task<Configuration?> ObtenerConfiguracionAsync();
    }
}
