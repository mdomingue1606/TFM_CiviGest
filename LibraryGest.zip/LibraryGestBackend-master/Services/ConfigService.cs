﻿using LibraryGest.Context;
using LibraryGest.Models;
using Microsoft.EntityFrameworkCore;

namespace LibraryGest.Services
{
    public class ConfigService : IConfigService
    {
        private readonly ApplicationDbContext context;
        public ConfigService(ApplicationDbContext context)
        {
            this.context = context;
        }

        public async Task<Configuration?> ObtenerConfiguracionAsync()
        {

            return await context.Configuration.FirstOrDefaultAsync();
        }
    }
}
