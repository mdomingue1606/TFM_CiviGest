﻿using LibraryGest.Models;

namespace LibraryGest.Services
{
    public interface ICurrentInfoAuthService
    {
        CurrentUserInfoAuth ObtenerInfoAuth(HttpRequest request);
    }
}
