﻿using LibraryGest.Models;

namespace LibraryGest.Services
{
    public interface IArchiveService
    {
        Task<ArchiveDetailsDTO?> ObtenerArchivoDetallesIdAsync(int id);
        Task<PageResult<ArchiveDetailsDTO>> ObtenerArchivosAsync(ArchiveSearchParams pSearchParams);
        Task<int> CrearArchivoAsync(ArchiveCreateDTO data, int UserCreatedId);
        Task<bool> ActualizarArchivoAsync(int id, ArchiveDetailsDTO data, CurrentUserInfoAuth infoUser);
        Task<bool> EliminarArchivoAsync(int id, CurrentUserInfoAuth infoUser);
        bool ExisteArchivo(int id);
    }
}
