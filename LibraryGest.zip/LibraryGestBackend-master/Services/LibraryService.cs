﻿using LibraryGest.Context;
using LibraryGest.Models;
using LibraryGest.Models.Enum;
using LibraryGest.Models.Extensions;
using Microsoft.DotNet.Scaffolding.Shared;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;

namespace LibraryGest.Services
{
    public class LibraryService : ILibraryService
    {
        private readonly ApplicationDbContext context;

        public LibraryService(ApplicationDbContext context)
        {
            this.context = context;
        }

        public async Task<Library?> ObtenerBibliotecaIdAsync(int id)
        {
            return await context.Library.FindAsync(id);
        }

        public async Task<LibraryDetailsDTO?> ObtenerBibliotecaDetallesIdAsync(int id)
        {
            Library library = await ObtenerBibliotecaIdAsync(id);
            LibraryDetailsDTO? res = null;
            if (library != null)
            {
                res = library.ToDetailsDTO();
            }
            return res;
        }

        public async Task CrearBibliotecaAsync(LibraryCreateDTO data, int UserCreatedId)
        {
            //Check if email is already in the system
            bool emailExists = await context.Library.AnyAsync(p => p.Email == data.Email);
            if (emailExists)
            {
                throw new ArgumentException("El email ya está registrado.");
            }
            //Check if dni is already in the system
            bool cifExists = await context.Library.AnyAsync(p => p.CIF == data.CIF);
            if (cifExists)
            {
                throw new ArgumentException("El CIF ya está registrado.");
            }

            var library = data.ToLibrary();
            //Add the user who is creating the library
            library.UserCreatedId = UserCreatedId;

            context.Library.Add(library);
            await context.SaveChangesAsync();
        }

        public async Task<bool> EliminarBibliotecaAsync(int id, CurrentUserInfoAuth infoUser)
        {

            var library = await ObtenerBibliotecaIdAsync(id);
            if (library != null)
            {
                //If it is a gestor he only can remove his own libraries.
                if (infoUser.Role == RoleEnum.Gestor.ToString() && library.UserCreatedId != infoUser.Id)
                {
                    throw new UnauthorizedAccessException("No tienes permisos para ello");
                }

                context.Remove(library);
                await context.SaveChangesAsync();
                return true;

            }
            return false;

        }

        public async Task<PageResult<LibraryDetailsDTO>> ObtenerBibliotecasAsync(LibrarySearchParams pSearchParams)
        {
            var query = context.Library.AsQueryable();

            // Filter for the name
            if (!string.IsNullOrEmpty(pSearchParams.Name))
            {
                query = query.Where(p => p.Name.Contains(pSearchParams.Name));
            }

            // Order by name
            if (pSearchParams.OrderField?.ToLower() == "nombre")
            {
                query = pSearchParams.OrderBy?.ToLower() == "desc"
                    ? query.OrderByDescending(p => p.Name)
                    : query.OrderBy(p => p.Name);
            }

            //Get totalElements
            var totalItems = await query.CountAsync();

            //Get totalPages
            var totalPages = (int)Math.Ceiling(totalItems / (double)pSearchParams.PageSize);

            // Pages.
            query = query.Skip(pSearchParams.PageNum * pSearchParams.PageSize)
                         .Take(pSearchParams.PageSize);

            var list = await query.ToListAsync();

            // Convert to DTO
            List<LibraryDetailsDTO> libraries = list.Select(p => p.ToDetailsDTO()).ToList();
            return new PageResult<LibraryDetailsDTO>
            {
                Items = libraries,
                TotalItems = totalItems,
                TotalPages = totalPages,
                CurrentPage = pSearchParams.PageNum,
                PageSize = pSearchParams.PageSize
            };
        }

        public async Task<bool> ActualizarBibliotecaAsync(int id, LibraryDetailsDTO data, CurrentUserInfoAuth infoUser)
        {
            Library library = await ObtenerBibliotecaIdAsync(id);
            if (library != null)
            {
                //If it is a gestor he only can update his own libraries.
                if (infoUser.Role == RoleEnum.Gestor.ToString() && library.UserCreatedId != infoUser.Id)
                {
                    throw new UnauthorizedAccessException("No tienes permisos para ello");
                }
                //Update values
                
                library.Description = (data.Description.IsNullOrEmpty()) ? library.Description : data.Description;
                library.PhoneNumber = (data.PhoneNumber.IsNullOrEmpty()) ? library.PhoneNumber : data.PhoneNumber;
                library.FloorNumbers = (data.FloorNumbers < 0) ? library.FloorNumbers : data.FloorNumbers;

                //Update photo
                if (!string.IsNullOrEmpty(data.Photo) && !string.IsNullOrEmpty(data.PhotoMimeType))
                {
                    library.PhotoMimeType = data.PhotoMimeType;
                    library.Photo = Convert.FromBase64String(data.Photo);
                }

                context.Entry(library).State = EntityState.Modified;
                await context.SaveChangesAsync();
                return true;
            }
            return false;

        }

        public bool ExisteBiblioteca(int id)
        {
            return context.Library.Any(e => e.Id == id);
        }

    }
}
