﻿namespace BasicGest.Models.Extensions
{
    public static class ProviderExtensions
    {

        public static ProviderDetailsDTO ToDetailsDTO(this Provider provider)
        {
            return new ProviderDetailsDTO
            {
               Address = provider.Address,
               DNI = provider.DNI,
               Email = provider.Email,
               Name = provider.Name,
               PhoneNumber = provider.PhoneNumber,
               ContactPersonName = provider.ContactPersonName,
               UserCreatedId = provider.UserCreatedId,
               Id=provider.Id
               
            };
        }
        public static Provider ToProvider(this ProviderCreateDTO provider)
        {
            return new Provider
            {
               ContactPersonName = provider.ContactPersonName,
               Address = provider.Address,
               PhoneNumber= provider.PhoneNumber,
               Name = provider.Name,
               DNI= provider.DNI,
               Email = provider.Email,
            };
        }
    }
}
