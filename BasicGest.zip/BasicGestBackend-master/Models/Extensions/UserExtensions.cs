﻿
namespace BasicGest.Models.Extensions
{
    public static class UserExtensions
    {
        public static UserDetailsAdminDTO ToAdminDTO(this User user)
        {
            return new UserDetailsAdminDTO
            {
                Name = user.Name,
                Email = user.Email,
                Surname = user.Surname,
                DNI = user.DNI,
                PhoneNumber = user.PhoneNumber,
                BirthdayDate = user.BirthdayDate,
                Address = user.Address,
                RegistrationDate = user.RegistrationDate,
                Role = user.Role.Name,
                Status = user.Status,
                Id = user.Id,
            };
        }

        public static UserDetailsDTO ToUserDetailDTO(this User user)
        {
            return new UserDetailsDTO
            {
                Name = user.Name,
                Email = user.Email,
                Surname = user.Surname,
                DNI = user.DNI,
                PhoneNumber = user.PhoneNumber,
                BirthdayDate = user.BirthdayDate,
                Address = user.Address,
                RegistrationDate = user.RegistrationDate,
                Role = user.Role.Name,
                Password = user.Password,
                Status = user.Status,
            };
        }

        public static User ToUser(this UserCreateDTO userCreateDTO, UserRole role)
        {
            return new User
            {
                Name = userCreateDTO.Name,
                Email = userCreateDTO.Email,
                Surname = userCreateDTO.Surname,
                DNI = userCreateDTO.DNI,
                PhoneNumber = userCreateDTO.PhoneNumber,
                Password = userCreateDTO.Password,
                BirthdayDate = userCreateDTO.BirthdayDate,
                Address = userCreateDTO.Address,
                Role = role,
                UserRoleId = role.Id,
                
            };
        }

    }
}
