﻿namespace BasicGest.Models.Enum
{
    public enum StatusUserEnum
    {
        Activo,
        Inactivo,
        Sancionado
    }
}
