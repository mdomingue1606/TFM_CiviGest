﻿using System.Text.Json.Serialization;

namespace BasicGest.Models
{
    public class User
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }
        public string Surname { get; set; }
        public string DNI { get; set; }
        public string PhoneNumber { get; set; }
        public DateTime BirthdayDate { get; set; }
        public string Address { get; set; }
        public DateTime RegistrationDate { get; set; }

        public int UserRoleId { get; set; }
        public UserRole Role { get; set; }
        public string Status { get; set; }

    }

    //Model for the loggin of the user
    public class UserLoginDTO
    {
        public string Pwd { get; set; }
        public string Email { get; set; }
    }

    //Model for the response of the validation of the user.
    public class UserValidaionLoginDTO
    {
        public string Email { get; set; }
        public bool IsValid { get; set; }
        public string Role { get; set; }
        public string? Reason { get; set; }
        public int Id { get; set; }
    }

    //Model for getting user details
    //Also using for creating a new user in the app
    public class UserDetailsDTO
    {
        public string Name { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }
        public string Surname { get; set; }
        public string DNI { get; set; }
        public string PhoneNumber { get; set; }
        public DateTime BirthdayDate { get; set; }
        public string Address { get; set; }
        public DateTime RegistrationDate { get; set; }
        public string Role { get; set; }
        public string Status { get; set; }
    }

    //Model for getting user info for the admin and gestor people
    public class UserDetailsAdminDTO
    {
        public string Name { get; set; }
        public string Email { get; set; }
        public string Surname { get; set; }
        public string DNI { get; set; }
        public string PhoneNumber { get; set; }
        public DateTime BirthdayDate { get; set; }
        public string Address { get; set; }
        public DateTime RegistrationDate { get; set; }
        public string Role { get; set; }
        public string Status { get; set; }
        public int Id { get; set; }
    }

    //For making the search of the user in the database.
    public class UserSearchParams
    {
        public int PageNum { get; set; } = 0;
        public int PageSize { get; set; } = 10;
        public string? Name { get; set; }
        public string? Surname { get; set; }
        public string? Status { get; set; }
        public string? OrderBy { get; set; }
        public string? OrderField { get; set; }
    }

    //For creating a new user in the app
    public class UserCreateDTO
    {
        public string Name { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }
        public string Surname { get; set; }
        public string DNI { get; set; }
        public string PhoneNumber { get; set; }
        public DateTime BirthdayDate { get; set; }
        public string Address { get; set; }
    }
}
