﻿using System.Text.Json;
using BasicGest.Models;
using Microsoft.EntityFrameworkCore;

namespace BasicGest.Context
{
    public class ApplicationDbContext :DbContext
    {
        public DbSet <User> User { get; set; }
        public DbSet <Configuration> Configuration {get;set;}
        public DbSet <UserRole> UserRole { get; set; }
        public DbSet <Provider> Provider { get; set; }

        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
       : base(options)
        {
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Configuration>()
                .Property(c => c.Audience)
                .HasConversion(
                    v => SerializeList(v),
                    v => DeserializeList(v));

            //Relation between User and USerRole
            modelBuilder.Entity<User>()
                .HasOne(u => u.Role)
                .WithMany()
                .HasForeignKey(u => u.UserRoleId)
                .OnDelete(DeleteBehavior.Restrict);

            //Unique values for email and DNI Provider
            modelBuilder.Entity<User>()
                .HasIndex(u => u.Email)
                .IsUnique();
            modelBuilder.Entity<User>()
                .HasIndex(U => U.DNI)
                .IsUnique();

            //Unique values for email and DNI Provider
            modelBuilder.Entity<Provider>()
                .HasIndex(p => p.Email)
                .IsUnique();
            modelBuilder.Entity<Provider>()
                .HasIndex(p => p.DNI)
                .IsUnique();

            //Relation between Provider and User
            modelBuilder.Entity<Provider>()
                .HasOne(p => p.UserCreated)
                .WithMany()
                .HasForeignKey(p => p.UserCreatedId)
                .OnDelete(DeleteBehavior.Restrict);
        }

        private string SerializeList(List<string> list)
        {
            return JsonSerializer.Serialize(list);
        }

        // Deserialize Method
        private List<string> DeserializeList(string json)
        {
            Console.WriteLine(json);
            return JsonSerializer.Deserialize<List<string>>(json);
        }
    }
}
