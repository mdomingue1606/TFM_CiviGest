﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using BasicGest.Context;
using BasicGest.Models;
using BasicGest.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity.Data;
using Microsoft.IdentityModel.Tokens;

namespace BasicGest.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UsersController : ControllerBase
    {
        private readonly IUserService userService;
        private readonly ICurrentInfoAuthService currentInfoAuthService;

        public UsersController(IUserService userService, ICurrentInfoAuthService currentInfoAuthService)
        {
            this.userService = userService;
            this.currentInfoAuthService = currentInfoAuthService;
        }

        // GET: api/Users
        [HttpGet]
        [Authorize(Roles = "Admin,Gestor")]
        public async Task<ActionResult<PageResult<UserDetailsAdminDTO>>> GetUser(int npag=0, int nelem=10, string? nombre=null, string? apellido=null, string? estado= null, string? orden=null, string? campoOrden=null)
        {
            UserSearchParams uSearchParams = new UserSearchParams
            {
                PageSize = nelem,
                Name = nombre,
                Surname = apellido,
                PageNum = npag,
                OrderBy = orden,
                OrderField = campoOrden,
                Status = estado,
            };
            return await userService.ObtenerUsuariosAsync(uSearchParams);
        }

        // GET: api/Users/{id}
        [HttpGet("{id}")]
        [Authorize]
        public async Task<ActionResult<UserDetailsDTO?>> GetUser(int id)
        {
            try
            {
                CurrentUserInfoAuth infoUser = currentInfoAuthService.ObtenerInfoAuth(Request);

                var user = await userService.ObtenerUsuarioIdAsync(id, infoUser);
                if (user == null)
                {
                    return NotFound();
                }
                else
                {
                    return user;
                }
            }
            catch(UnauthorizedAccessException ex)
            {
                return Unauthorized(ex.Message);
            }
            
        }

        //POST: api/Users/validate
        [HttpPost("validate")]
        public async Task<IActionResult> ValidateCredentials([FromBody] UserLoginDTO request)
        {
            UserValidaionLoginDTO userValidation = await userService.ValidarCredencialesAsync(request.Email, request.Pwd);

            if (!userValidation.IsValid)
            {
                return Unauthorized(userValidation.Reason);
            }

            return Ok(userValidation); 
        }


        // PUT: api/Users/{id} --> Update
        [HttpPut("{id}")]
        [Authorize]
        public async Task<IActionResult> PutUser(int id, [FromBody] UserDetailsDTO user)
        {
            try
            {
                CurrentUserInfoAuth infoUser = currentInfoAuthService.ObtenerInfoAuth(Request);
               
                await userService.ActualizarUsuarioAsync(user, infoUser);
                
                return NoContent();
            }
            catch (UnauthorizedAccessException ex)
            {
                return Unauthorized(ex.Message);
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!userService.ExisteUsuario(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

        }
        
        // POST: api/Users --> Create
        [HttpPost]
        public async Task<ActionResult<UserDetailsDTO>> PostUser(UserCreateDTO user)
        {
            try
            {
                await userService.CrearUsuarioAsync(user);

                return Created("", new { message = "usuario creado", user.Email });
            }
            catch(ArgumentException ex)
            {
                return BadRequest(new { error = ex.Message });
            }
        }
        
        // DELETE: api/Users/5
        [HttpDelete("{id}")]
        [Authorize]
        public async Task<IActionResult> DeleteUser(int id)
        {
            try
            {
                CurrentUserInfoAuth infoUser = currentInfoAuthService.ObtenerInfoAuth(Request);
                var res = await userService.EliminarUsuarioAsync(id, infoUser);
                if (!res)
                {
                    return NotFound();
                }

                return NoContent();
            }
            catch (UnauthorizedAccessException ex)
            {
                return Unauthorized(ex.Message);
            }

        }

    }
}
