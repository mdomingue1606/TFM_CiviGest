﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using BasicGest.Context;
using BasicGest.Models;
using Microsoft.AspNetCore.Authorization;
using BasicGest.Services;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace BasicGest.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProvidersController : ControllerBase
    {
        private readonly IProviderService providerService;
        private readonly ICurrentInfoAuthService currentInfoAuthService;

        public ProvidersController(IProviderService providerService, ICurrentInfoAuthService currentInfoAuthService)
        {
            this.providerService = providerService;
            this.currentInfoAuthService = currentInfoAuthService;
        }

        // GET: api/Providers
        [HttpGet]
        [Authorize(Roles = "Admin,Gestor")]
        public async Task<ActionResult<PageResult<ProviderDetailsDTO>>> GetProvider(int npag = 0, int nelem = 10, string? nombre = null, string? orden = null, string? campoOrden = null)
        {
            ProviderSearchParams pSearchParams = new ProviderSearchParams
            {
                PageSize = nelem,
                Name = nombre,
                PageNum = npag,
                OrderBy = orden,
                OrderField = campoOrden,
            };
            return await providerService.ObtenerProveedoresAsync(pSearchParams);
        }

        // GET: api/Providers/5
        [HttpGet("{id}")]
        [Authorize(Roles = "Admin,Gestor")]
        public async Task<ActionResult<ProviderDetailsDTO>> GetProvider(int id)
        {
            var provider = await providerService.ObtenerProveedorDetallesIdAsync(id);

            if (provider == null)
            {
                return NotFound();
            }

            return provider;
        }

        // PUT: api/Providers/5 ---> UPDATE
        [HttpPut("{id}")]
        [Authorize(Roles = "Admin,Gestor")]
        public async Task<IActionResult> PutProvider(int id, [FromBody] ProviderDetailsDTO provider)
        {
            try
            {
                CurrentUserInfoAuth infoUser = currentInfoAuthService.ObtenerInfoAuth(Request);
                var res = await providerService.ActualizarProveedorAsync(id, provider, infoUser);
                if (!res)
                {
                    return NotFound();
                }
                return NoContent();
            }
            catch (UnauthorizedAccessException ex)
            {
                return Unauthorized(ex.Message);
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!providerService.ExisteProveedor(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }
        }

        // POST: api/Providers
        [HttpPost]
        [Authorize(Roles = "Admin,Gestor")]
        public async Task<ActionResult<ProviderDetailsDTO>> PostProvider(ProviderCreateDTO provider)
        {
            try
            {
                CurrentUserInfoAuth infoUser = currentInfoAuthService.ObtenerInfoAuth(Request);
                if(infoUser.Id == null)
                {
                    return BadRequest("El token no está bien formado");
                }
                await providerService.CrearProveedorAsync(provider, infoUser.Id.Value);

                return Created("", new { message = "Proveedor creado", provider.Name });
            }
            catch (ArgumentException ex)
            {
                return BadRequest(new { error = ex.Message });
            }
        }

        // DELETE: api/Providers/5
        [HttpDelete("{id}")]
        [Authorize(Roles = "Admin,Gestor")]
        public async Task<IActionResult> DeleteProvider(int id)
        {
            try
            {
                CurrentUserInfoAuth infoUser = currentInfoAuthService.ObtenerInfoAuth(Request);
                var res = await providerService.EliminarProveedorAsync(id, infoUser);
                if (!res)
                {
                    return NotFound();
                }

                return NoContent();
            }
            catch (UnauthorizedAccessException ex)
            {
                return Unauthorized(ex.Message);
            }
        }
    }
}
