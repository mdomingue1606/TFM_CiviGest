﻿using BasicGest.Context;
using BasicGest.Models;

namespace BasicGest.Services
{
    public interface IProviderService
    {
        Task<PageResult<ProviderDetailsDTO>> ObtenerProveedoresAsync(ProviderSearchParams pSearchParams);
        Task<ProviderDetailsDTO?> ObtenerProveedorDetallesIdAsync(int id);
        Task<Provider?> ObtenerProveedorEmailAsync(string email);
        Task CrearProveedorAsync(ProviderCreateDTO data, int UserCreatedId);
        Task<bool> ActualizarProveedorAsync(int id, ProviderDetailsDTO data, CurrentUserInfoAuth infoUser);
        Task<bool> EliminarProveedorAsync(int id, CurrentUserInfoAuth infoUser);
        bool ExisteProveedor(int id);

    }
}
