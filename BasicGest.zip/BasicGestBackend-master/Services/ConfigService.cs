﻿using BasicGest.Context;
using BasicGest.Models;
using Microsoft.EntityFrameworkCore;

namespace BasicGest.Services
{
    public class ConfigService: IConfigService
    {
        private readonly ApplicationDbContext context;
        public ConfigService(ApplicationDbContext context)
        {
            this.context = context;
        }

        public async Task<Configuration?> ObtenerConfiguracionAsync()
        {

            return await context.Configuration.FirstOrDefaultAsync();
        }
    }
}
