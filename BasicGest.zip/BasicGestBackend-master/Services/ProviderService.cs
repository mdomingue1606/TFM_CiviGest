﻿using BasicGest.Context;
using BasicGest.Models;
using BasicGest.Models.Enum;
using BasicGest.Models.Extensions;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;

namespace BasicGest.Services
{
    public class ProviderService : IProviderService
    {
        private readonly ApplicationDbContext context;
        public ProviderService(ApplicationDbContext context)
        {
            this.context = context;
        }

        public async Task<ProviderDetailsDTO?> ObtenerProveedorDetallesIdAsync(int id)
        {
            Provider provider = await ObtenerProveedorIdAsync(id);
            ProviderDetailsDTO? res = null;
            if (provider != null) { 
                res =  provider.ToDetailsDTO();
            }
            return res;
        }

        public async Task<Provider?> ObtenerProveedorIdAsync(int id)
        {
            return await context.Provider.FindAsync(id);
        }

        public async Task<Provider?> ObtenerProveedorEmailAsync(string email)
        {
            return await context.Provider.FirstOrDefaultAsync(p => p.Email == email);
        }

        public async Task<PageResult<ProviderDetailsDTO>> ObtenerProveedoresAsync(ProviderSearchParams pSearchParams)
        {
            var query = context.Provider.AsQueryable();

            // Filter for the name
            if (!string.IsNullOrEmpty(pSearchParams.Name))
            {
                query = query.Where(p => p.Name.Contains(pSearchParams.Name));
            }

            // Order by name
            if (pSearchParams.OrderBy?.ToLower() == "nombre")
            {
                query = pSearchParams.OrderField?.ToLower() == "desc"
                    ? query.OrderByDescending(p => p.Name)
                    : query.OrderBy(p => p.Name);
            }

            //Get totalElements
            var totalItems = await query.CountAsync();

            //Get totalPages
            var totalPages = (int)Math.Ceiling(totalItems / (double)pSearchParams.PageSize);

            // Pages.
            query = query.Skip(pSearchParams.PageNum * pSearchParams.PageSize)
                         .Take(pSearchParams.PageSize);

            var list = await query.ToListAsync();

            // Convert to DTO
            List<ProviderDetailsDTO> providers = list.Select(p => p.ToDetailsDTO()).ToList();
            return new PageResult<ProviderDetailsDTO>
            {
                Items = providers,
                TotalItems = totalItems,
                TotalPages = totalPages,
                CurrentPage = pSearchParams.PageNum,
                PageSize = pSearchParams.PageSize
            };
        }

        public async Task CrearProveedorAsync(ProviderCreateDTO data, int UserCreatedId)
        {
            //Check if email is already in the system
            bool emailExists = await context.Provider.AnyAsync(p => p.Email == data.Email);
            if (emailExists)
            {
                throw new ArgumentException("El email ya está registrado.");
            }
            //Check if dni is already in the system
            bool dniExists = await context.Provider.AnyAsync(p => p.DNI == data.DNI);
            if (dniExists)
            {
                throw new ArgumentException("El DNI ya está registrado.");
            }

            var provider = data.ToProvider();
            //Add the user who is creating the provider
            provider.UserCreatedId = UserCreatedId;

            context.Provider.Add(provider);
            await context.SaveChangesAsync();
        }

        public async Task<bool> ActualizarProveedorAsync(int id, ProviderDetailsDTO data, CurrentUserInfoAuth infoUser)
        {
            Provider provider = await ObtenerProveedorIdAsync(id);
            if (provider != null)
            {
                //If it is a gestor he only can update his own providers.
                if (infoUser.Role == RoleEnum.Gestor.ToString() && provider.UserCreatedId != infoUser.Id)
                {
                    throw new UnauthorizedAccessException("No tienes permisos para ello");
                }
                //Update values
                provider.Address = (data.Address.IsNullOrEmpty()) ? provider.Address: data.Address;
                provider.ContactPersonName = (data.ContactPersonName.IsNullOrEmpty()) ? provider.ContactPersonName : data.ContactPersonName;
                provider.PhoneNumber = (data.PhoneNumber.IsNullOrEmpty()) ? provider.PhoneNumber : data.PhoneNumber;


                context.Entry(provider).State = EntityState.Modified;
                await context.SaveChangesAsync();
                return true;
            }
            return false;

        }

        public async Task<bool> EliminarProveedorAsync(int id, CurrentUserInfoAuth infoUser)
        {
            
            var provider = await ObtenerProveedorIdAsync(id);
            if (provider != null)
            {
                //If it is a gestor he only can remove his own providers.
                if (infoUser.Role == RoleEnum.Gestor.ToString() && provider.UserCreatedId != infoUser.Id)
                {
                    throw new UnauthorizedAccessException("No tienes permisos para ello");
                }

                context.Remove(provider);
                await context.SaveChangesAsync();
                return true;
                
            }
            return false;
            
        }

        public bool ExisteProveedor(int id)
        {
            return context.Provider.Any(e => e.Id == id);
        }

        

       

        
    }
}
