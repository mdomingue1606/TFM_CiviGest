﻿using BasicGest.Models;

namespace BasicGest.Services
{
    public interface IUserService
    {
        Task<PageResult<UserDetailsAdminDTO>> ObtenerUsuariosAsync(UserSearchParams uSearchParams);
        Task<UserDetailsDTO?> ObtenerUsuarioIdAsync(int id, CurrentUserInfoAuth authInfo);
        Task<User?> ObtenerUsuarioEmailAsync(string email);
        Task CrearUsuarioAsync(UserCreateDTO data);
        Task ActualizarUsuarioAsync(UserDetailsDTO data, CurrentUserInfoAuth authInfo);
        Task<bool> EliminarUsuarioAsync(int id, CurrentUserInfoAuth authInfo);
        bool ExisteUsuario(int id);
        Task<UserValidaionLoginDTO> ValidarCredencialesAsync(string email, string pwd);

    }
}
