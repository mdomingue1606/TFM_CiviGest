﻿using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using Azure.Core;
using BasicGest.Models;
using Microsoft.IdentityModel.Tokens;

namespace BasicGest.Services
{
    public class CurrentInfoAuthService :ICurrentInfoAuthService
    {
        public CurrentInfoAuthService() { 
        }

        public CurrentUserInfoAuth ObtenerInfoAuth (HttpRequest request)
        {
            var token = request.Headers["Authorization"].ToString().Replace("Bearer ", "");
            if (string.IsNullOrWhiteSpace(token))
            {
                throw new ArgumentException("Se necesita el token");
            }
            CurrentUserInfoAuth info = new CurrentUserInfoAuth();

            var tokenHandler = new JwtSecurityTokenHandler();
            try
            {
                var jwtToken = tokenHandler.ReadJwtToken(token);
                info.Token = token;
                info.Email = jwtToken.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Name).Value;
                info.Role = jwtToken.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Role).Value;
                info.Id = int.Parse(jwtToken.Claims.FirstOrDefault(c => c.Type == ClaimTypes.NameIdentifier).Value);
                return info;
            }
            catch (Exception ex)
            {
                throw new UnauthorizedAccessException("Invalid Token.", ex);
            }
        }

    }
}
