﻿using BasicGest.Context;
using BasicGest.Models;
using BasicGest.Models.Enum;
using BasicGest.Models.Extensions;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;
using Microsoft.CodeAnalysis.Scripting;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using Microsoft.VisualStudio.Web.CodeGenerators.Mvc.Templates.BlazorIdentity.Pages.Manage;
using NuGet.Protocol.Core.Types;

namespace BasicGest.Services
{
    public class UserService : IUserService
    {
        private readonly ApplicationDbContext context;

        public UserService(ApplicationDbContext context)
        {
            this.context = context;
        }

        public async Task<PageResult<UserDetailsAdminDTO>> ObtenerUsuariosAsync(UserSearchParams uSearchParams)
        {
            var query = context.User.Include(u => u.Role).AsQueryable();

            // Filter for the name
            if (!string.IsNullOrEmpty(uSearchParams.Name))
            {
                query = query.Where(u => u.Name.Contains(uSearchParams.Name));
            }

            // Filter for the surname
            if (!string.IsNullOrEmpty(uSearchParams.Surname))
            {
                query = query.Where(u => u.Surname.Contains(uSearchParams.Surname));
            }

            //Filter for the status
            if (!string.IsNullOrEmpty(uSearchParams.Status) && EsValidoEstado(uSearchParams.Status))
            {
                query = query.Where(u=>u.Status.Contains(uSearchParams.Status));
            }

            // Order by name
            if (uSearchParams.OrderField?.ToLower() == "nombre")
            {
                query = uSearchParams.OrderBy?.ToLower() == "desc"
                    ? query.OrderByDescending(u => u.Name)
                    : query.OrderBy(u => u.Name);
            }
            // Order by surname
            else if (uSearchParams.OrderField?.ToLower() == "apell")
            {
                query = uSearchParams.OrderBy?.ToLower() == "desc"
                    ? query.OrderByDescending(u => u.Surname)
                    : query.OrderBy(u => u.Surname);
            }

            //Get totalElements
            var totalItems = await query.CountAsync();

            //Get totalPages
            var totalPages = (int)Math.Ceiling(totalItems / (double)uSearchParams.PageSize);

            // Pages.
            query = query.Skip(uSearchParams.PageNum * uSearchParams.PageSize)
                         .Take(uSearchParams.PageSize);

            var list = await query.ToListAsync();

            // Convert to DTO
            List<UserDetailsAdminDTO> users = list.Select(u => u.ToAdminDTO()).ToList();
            return new PageResult<UserDetailsAdminDTO>
            {
                Items = users,
                TotalItems = totalItems,
                TotalPages = totalPages,
                CurrentPage = uSearchParams.PageNum,
                PageSize = uSearchParams.PageSize
            };
        }

        public async Task<UserDetailsDTO?> ObtenerUsuarioIdAsync(int id, CurrentUserInfoAuth authInfo)
        {
            //Check if it is the info of itself or if is admin or gestor
            if(id != authInfo.Id && authInfo.Role != RoleEnum.Admin.ToString() && authInfo.Role != RoleEnum.Gestor.ToString()) {
                throw new UnauthorizedAccessException("No tienes permisos para ello");
            }
            else
            {
                UserDetailsDTO res = null;
                var user = await ObtenerUsuarioIdAsync(id);
                if(user != null)
                {
                    res = user.ToUserDetailDTO();
                    if(id != authInfo.Id)
                    {
                        //If it is not itself, we delete the password information.
                        res.Password = null;
                    }

                }
                return res;
            }
        }

        public async Task<User?> ObtenerUsuarioIdAsync(int id)
        {
            return await context.User.Include(u => u.Role).FirstOrDefaultAsync(u => u.Id == id);
        }

        public async Task<User?> ObtenerUsuarioEmailAsync(string email)
        {
            return await context.User.Include(u => u.Role).FirstOrDefaultAsync(u => u.Email == email);
        }

        public async Task CrearUsuarioAsync(UserCreateDTO data)
        {
            //Check if email is already in the system
            bool emailExists = await context.User.AnyAsync(u => u.Email == data.Email);
            if (emailExists)
            {
                throw new ArgumentException("El email ya está registrado.");
            }
            //Check if dni is already in the system
            bool dniExists = await context.User.AnyAsync(u => u.DNI == data.DNI);
            if (dniExists)
            {
                throw new ArgumentException("El DNI ya está registrado.");
            }

            var userRole = await context.UserRole.FirstOrDefaultAsync(u => u.Name == RoleEnum.Cliente.ToString());
            if (userRole == null)
            {
                throw new ArgumentException("El rol especificado no existe.");
            }
            var user = data.ToUser(userRole);

            user.Password = BCrypt.Net.BCrypt.HashPassword(user.Password);
            user.RegistrationDate = DateTime.UtcNow;
            user.Status = StatusUserEnum.Activo.ToString();

            context.User.Add(user);
            await context.SaveChangesAsync();
        }

        public async Task ActualizarUsuarioAsync(UserDetailsDTO data, CurrentUserInfoAuth authInfo)
        {
            if (data.Email != authInfo.Email && authInfo.Role != RoleEnum.Admin.ToString() && authInfo.Role != RoleEnum.Gestor.ToString())
            {
                throw new UnauthorizedAccessException("No tienes permisos para ello");
            }

            //Change own user.
            User? user = null;
            if(data.Email == authInfo.Email)
            {
                user = await ActualizarUsuarioPropioAsync(data);
            }
            else
            {
                user = await ActualizarOtroUsuarioAsync(data, authInfo.Role);
            }

            if (user != null)
            {
                context.Entry(user).State = EntityState.Modified;
                //context.User.Update(user);
                await context.SaveChangesAsync();
            }
        }

        public async Task<bool> EliminarUsuarioAsync(int id, CurrentUserInfoAuth authInfo)
        {
            if (id != authInfo.Id && authInfo.Role != RoleEnum.Admin.ToString() && authInfo.Role != RoleEnum.Gestor.ToString())
            {
                throw new UnauthorizedAccessException("No tienes permisos para ello");
            }
            else
            {
                var user = await ObtenerUsuarioIdAsync(id);
                if (user != null)
                {
                    context.Remove(user);
                    await context.SaveChangesAsync();
                    return true;
                }
                return false;
            }

        }

        public bool ExisteUsuario(int id)
        {
            return context.User.Any(e => e.Id == id);
        }

        public async Task<UserValidaionLoginDTO> ValidarCredencialesAsync(string email, string pwd)
        {
            User user = await ObtenerUsuarioEmailAsync(email);
            UserValidaionLoginDTO res = new UserValidaionLoginDTO();
            if (user == null) 
            {
                res.IsValid = false;
                res.Reason = "not user";
            }
            else if(!BCrypt.Net.BCrypt.Verify(pwd, user.Password))
            {
                res.IsValid = false;
                res.Reason = "wrong pwd";
            }
            else
            {
                res.IsValid = true;
                res.Role = user.Role.Name;
                res.Email = user.Email;
                res.Id = user.Id;
            }
            return res;
        }

        private async Task<User?> ActualizarUsuarioPropioAsync(UserDetailsDTO data)
        {
            User user = await ObtenerUsuarioEmailAsync(data.Email);
            if (user != null)
            {
                //Check if it is changing his own status.
                if (data.Status.Equals(StatusUserEnum.Inactivo.ToString()))
                {
                    user.Status = StatusUserEnum.Inactivo.ToString();
                }

                user.Address = data.Address;
                if (!data.Password.IsNullOrEmpty())
                {
                    user.Password = BCrypt.Net.BCrypt.HashPassword(data.Password);
                }
                user.PhoneNumber = data.PhoneNumber;
                user.BirthdayDate = data.BirthdayDate;

                //Check if is admin and want to change his rol.
                if (user.Role.Name.Equals(RoleEnum.Admin.ToString()) && !user.Role.Name.Equals(data.Role))
                {
                    var userRole = await context.UserRole.FirstOrDefaultAsync(u => u.Name == data.Role);
                    if (userRole != null) {
                        user.Role = userRole;
                        user.UserRoleId = userRole.Id;
                    }
                }
            }
            return user;
        }

        private async Task<User?> ActualizarOtroUsuarioAsync(UserDetailsDTO data, string authRole)
        {
            User user = await ObtenerUsuarioEmailAsync(data.Email);
            if(user != null)
            {
                //He can change the status.
                if(EsValidoEstado(data.Status))
                    user.Status = data.Status;
                //If is admin, also can change the role.
                if (authRole.Equals(RoleEnum.Admin.ToString()))
                {
                    var userRole = await context.UserRole.FirstOrDefaultAsync(u => u.Name == data.Role);
                    if (userRole != null)
                    {
                        user.Role = userRole;
                        user.UserRoleId = userRole.Id;
                    }
                }
            }
            return user;
        }

        private bool EsValidoEstado(string status)
        {
            bool isvalid = false;
            if (!status.IsNullOrEmpty())
            {
                isvalid = status.Equals(StatusUserEnum.Activo.ToString()) || status.Equals(StatusUserEnum.Inactivo.ToString()) || status.Equals(StatusUserEnum.Sancionado.ToString());
            }
            return isvalid;
        }
    }
}
