﻿using BasicGest.Models;

namespace BasicGest.Services
{
    public interface ICurrentInfoAuthService
    {
        CurrentUserInfoAuth ObtenerInfoAuth(HttpRequest request);
        //string ObtenerToken(HttpRequest request);
    }
}
