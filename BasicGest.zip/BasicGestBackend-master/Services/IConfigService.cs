﻿

using BasicGest.Models;

namespace BasicGest.Services
{
    public interface IConfigService
    {
        Task<Configuration?> ObtenerConfiguracionAsync();
    }
}
