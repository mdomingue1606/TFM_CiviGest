﻿using System.IdentityModel.Tokens.Jwt;
using System.Net.Http;
using System.Net.Http.Json;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using AuthUtility.Context;
using AuthUtility.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using Newtonsoft.Json;

namespace AuthUtility.Services
{
    public class AuthService :IAuthService
    {
        private readonly ApplicationDbContext context;
        private readonly Configuration conf;
        private readonly HttpClient httpClient;

        public AuthService(ApplicationDbContext context, HttpClient httpClient)
        {
            this.context = context;
            this.conf = ObtenerConfiguracionAsync().Result;

            
            var handler = new HttpClientHandler
            {
                ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => true
            };

            
            this.httpClient = new HttpClient(handler);
        }

        public async Task<Configuration?> ObtenerConfiguracionAsync()
        {

            return await context.Configuration.FirstOrDefaultAsync();
        }

        public string GenerarAuthToken(string email, string role, int id)
        {
            var claims = new List<Claim>
            {
                new Claim(ClaimTypes.Name, email),
                new Claim(ClaimTypes.Role, role),
                new Claim(ClaimTypes.NameIdentifier, id.ToString())
            };

            //Add audiences:
            foreach(var audience in conf.Audience)
            {
                claims.Add(new Claim(JwtRegisteredClaimNames.Aud, audience));
            }

            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(conf.Key));
            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);
            var expirationDate = DateTime.UtcNow.AddHours(2);

            var token = new JwtSecurityToken(
                issuer: this.conf.Issuer,
                claims: claims,
                expires: expirationDate,
                signingCredentials: creds
            );

            return new JwtSecurityTokenHandler().WriteToken(token);

        }
        //For getting the refreshToken in order to avoid the new login for the user.
        public string GenerarRefreshToken()
        {
            return Convert.ToBase64String(RandomNumberGenerator.GetBytes(64));
        }

        public async Task CrearTokenAsync(string token, string email)
        {
            Token tokenEntity = new Token
            {
                TokenAuth = token,
                Email = email,
                Expiration = DateTime.UtcNow.AddDays(7)
            };
            context.Token.Add(tokenEntity);
            await context.SaveChangesAsync();
        }
        
        public async Task ActualizarTokenAsync(string token, string email)
        {
            var tokenEntity = await ObtenerTokenUserAsync(email);
            var expiration = DateTime.UtcNow.AddDays(7);
            if (tokenEntity != null)
            {
                tokenEntity.TokenAuth = token;
                tokenEntity.Expiration = expiration;
                await context.SaveChangesAsync();
            }
            else
            {
                await CrearTokenAsync(token, email);
            }
        }

        public async Task<Token?> ObtenerTokenUserAsync(string email)
        {
            return await context.Token.FirstOrDefaultAsync(t => t.Email == email);
        }
        public async Task<Token?> ObtenerTokenByIdAsync(int id)
        {
            return await context.Token.FindAsync(id);
        }
        public async Task<bool> EliminarTokenAsync(int id)
        {
            var token = await ObtenerTokenByIdAsync(id);
            if (token != null)
            {
                context.Token.Remove(token);
                await context.SaveChangesAsync();
                return true;
            }
            return false;
        }

        public async Task<bool> EliminarTokenByEmailAsync (string email)
        {
            var token = await ObtenerTokenUserAsync(email);
            if (token != null)
            {
                context.Token.Remove(token);
                await context.SaveChangesAsync();
                return true;
            }
            return false;
        }

        
        public async Task<UserValidationDTO> ValidarCredencialesAsync(UserLoginDTO userLoginDTO)
        {
            var response = await httpClient.PostAsJsonAsync(this.conf.UserServiceURL + "validate", userLoginDTO);
            if (!response.IsSuccessStatusCode)
            {
                return new UserValidationDTO
                {
                    IsValid = false,
                    Email = null
                };
            }

            var res = await response.Content.ReadAsStringAsync();
            return JsonConvert.DeserializeObject<UserValidationDTO>(res);
        }

        public string ValidarTokenYExtraerEmail(string token)
        {
            if (string.IsNullOrWhiteSpace(token))
            {
                throw new ArgumentException("Se necesita el token");
            }

            var tokenHandler = new JwtSecurityTokenHandler();
            try
            {
                var jwtToken = tokenHandler.ReadJwtToken(token);
                if (jwtToken.ValidTo < DateTime.UtcNow)
                {
                    throw new UnauthorizedAccessException("El token ha expirado");
                }

                var validationParameters = new TokenValidationParameters
                {
                    ValidateIssuer = true,
                    ValidateAudience = true,
                    ValidIssuer = this.conf.Issuer,
                    ValidAudience = String.Join(",", conf.Audience),
                    IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(conf.Key))
                };
                var validate = tokenHandler.ValidateToken(token, validationParameters, out var validatedToken);

                var emailClaim = validate.FindFirst(ClaimTypes.Name);
                if (emailClaim == null)
                {
                    throw new UnauthorizedAccessException("User ID not found in token.");
                }
                return emailClaim.Value;
            }
            catch (Exception ex)
            {
                throw new UnauthorizedAccessException("Invalid Token.", ex);
            }
        } 
    }
}
