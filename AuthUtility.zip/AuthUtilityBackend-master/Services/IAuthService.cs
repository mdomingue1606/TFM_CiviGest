﻿using AuthUtility.Models;

namespace AuthUtility.Services
{
    public interface IAuthService
    {
        string GenerarAuthToken(string email, string role, int id);
        Task CrearTokenAsync(string token, string email);
        Task ActualizarTokenAsync(string token, string email);
        Task<Token?> ObtenerTokenUserAsync(string email);
        Task<Token?> ObtenerTokenByIdAsync(int id);
        Task<bool> EliminarTokenAsync(int id);
        Task<bool> EliminarTokenByEmailAsync(string email);
        string GenerarRefreshToken();
        Task<UserValidationDTO> ValidarCredencialesAsync(UserLoginDTO userLoginDTO);
        string ValidarTokenYExtraerEmail(string token);

        Task<Configuration?> ObtenerConfiguracionAsync();

    }
}
