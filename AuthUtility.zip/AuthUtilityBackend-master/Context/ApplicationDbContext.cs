﻿using System.Text.Json;
using AuthUtility.Models;
using Microsoft.EntityFrameworkCore;

namespace AuthUtility.Context
{
    public class ApplicationDbContext :DbContext
    {
        public DbSet<Token> Token { get; set; }
        public DbSet<Configuration> Configuration { get; set; }

        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
       : base(options)
        {
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Configuration>()
                .Property(c => c.Audience)
                .HasConversion(
                    v => SerializeList(v), 
                    v => DeserializeList(v)); 
        }

        private string SerializeList(List<string> list)
        {
            return JsonSerializer.Serialize(list);
        }

        // Método para deserializar
        private List<string> DeserializeList(string json)
        {
            Console.WriteLine(json);
            return JsonSerializer.Deserialize<List<string>>(json);
        }

    }
}
