﻿using System.Text.Json;

namespace AuthUtility.Models
{
    public class UserLoginDTO
    {
        public string Email {  get; set; }
        public string Pwd { get; set; }

    }

    public class UserInfoDTO
    {
        public int Id { get; set; }
        public string Email { get; set; }
    }

    public class UserValidationDTO
    {
        public bool IsValid { get; set; }
        public string Email { get; set; }
        public string Role { get; set; }
        public string Reason { get; set; }
        public int Id { get; set; }
    }
}
