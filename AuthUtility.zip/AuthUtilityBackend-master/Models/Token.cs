﻿namespace AuthUtility.Models
{
    public class Token
    {
        public int Id { get; set; }
        public string TokenAuth { get; set; }
        public DateTime Expiration {  get; set; }
        public string Email { get; set; }


    }
}
