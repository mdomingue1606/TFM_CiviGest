﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.IdentityModel.Tokens.Jwt;
using Microsoft.IdentityModel.Tokens;
using Microsoft.EntityFrameworkCore;
using AuthUtility.Context;
using AuthUtility.Models;
using AuthUtility.Services;
using System.Security.Policy;
using Microsoft.VisualStudio.Web.CodeGenerators.Mvc.Templates.BlazorIdentity.Pages;
using NuGet.Common;
using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;

namespace AuthUtility.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly IAuthService authService;

        public AuthController(IAuthService authService)
        {
            this.authService = authService;
        }

        //POST: api/login
        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] UserLoginDTO request)
        {
            UserValidationDTO validation = await authService.ValidarCredencialesAsync(request);
            if (!validation.IsValid)
            {
                return Unauthorized("Credenciales erróneas");
            }

            var token = authService.GenerarAuthToken(request.Email, validation.Role, validation.Id);
            var refreshToken = authService.GenerarRefreshToken();

            await authService.ActualizarTokenAsync(refreshToken, validation.Email);
            return Ok(new {JwtToken = token, RefreshToken = refreshToken});
        }

        // POST: api/refreshToken
        [HttpPost("refreshToken")]
        public async Task<IActionResult> RefreshToken([FromBody] string email)
        {
            var jwtToken = Request.Headers["Authorization"].ToString().Replace("Bearer ", ""); //revisar

            var emailToken = authService.ValidarTokenYExtraerEmail(jwtToken);

            //Check that the email from the petition is equals to the token saved previously
            if(email != emailToken)
            {
                return Unauthorized("Los emails no son iguales");
            }

            var storedRefreshToken = await authService.ObtenerTokenUserAsync(email);

            if (storedRefreshToken == null || storedRefreshToken.Expiration < DateTime.UtcNow)
            {
                return Unauthorized("Token inválido o expirado");
            }
            //Getting the role from the claim of the token generated.
            var tokenHandler = new JwtSecurityTokenHandler();
            var jsonToken = tokenHandler.ReadToken(jwtToken) as JwtSecurityToken;

            
            var userRole = jsonToken?.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Role)?.Value;
            var userId = jsonToken?.Claims?.FirstOrDefault(c => c.Type == ClaimTypes.NameIdentifier)?.Value;

            if (string.IsNullOrEmpty(userRole))
            {
                return Unauthorized("El rol del usuario no está presente en el token.");
            }
            else if (string.IsNullOrEmpty(userId))
            {
                return Unauthorized("El id del usario no está presente en el token.");
            }

            //Generate new token
            var newToken = authService.GenerarAuthToken(email, userRole, int.Parse(userId));
            //Generate a new RefreshToken
            var newRefreshToken = authService.GenerarRefreshToken();

            await authService.ActualizarTokenAsync(newRefreshToken, email);

            return Ok(new { JwtToken = newToken, RefreshToken = newRefreshToken });


        }

        //POST: api/logout
        [HttpPost("logout")]
        [Authorize]
        public async Task<IActionResult> Logout()
        {
            //Get the email.
            var email = User.FindFirst(ClaimTypes.Name)?.Value;
            if (string.IsNullOrEmpty(email))
            {
                return Unauthorized("El email no está en el token.");
            }
            await authService.EliminarTokenByEmailAsync(email);
            return Ok(new { message = "Logout correcto" });
        }
    }
}
